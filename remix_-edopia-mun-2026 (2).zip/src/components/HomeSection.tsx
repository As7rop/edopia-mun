import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Calendar, MapPin, Award, ShieldAlert, ChevronRight, Users, Trophy } from "lucide-react";
import Logo from "./Logo";

interface HomeSectionProps {
  setActiveTab: (tab: string) => void;
  registeredUser: any;
}

export default function HomeSection({ setActiveTab, registeredUser }: HomeSectionProps) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  // Calculate live countdown to July 4, 2026 09:00:00 UTC
  useEffect(() => {
    const targetDate = new Date("2026-07-04T09:00:00Z").getTime();

    const updateClock = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const stats = [
    { label: "Elite Assemblies", value: "6", suffix: "Committees", icon: ShieldAlert, color: "text-rose-500" },
    { label: "Host Battleground", value: "DU", suffix: "Deshbandhu College", icon: MapPin, color: "text-emerald-500" },
    { label: "Prestige Purse", value: "₹40,000+", suffix: "Cash Pool", icon: Trophy, color: "text-amber-500" },
  ];

  return (
    <div id="home-section-container" className="space-y-16 pb-20 relative">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col items-center justify-center pt-24 px-4 overflow-hidden">
        {/* Background Radial Glow */}
        <div className="absolute inset-x-0 top-1/4 -z-10 flex transform-gpu justify-center overflow-hidden blur-3xl animate-pulse" style={{ animationDuration: "12s" }} aria-hidden="true">
          <div
            className="aspect-[1155/678] w-[72.1875rem] flex-none bg-gradient-to-tr from-brand to-brand-light opacity-25"
            style={{
              clipPath:
                "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
            }}
          />
        </div>

        {/* Dynamic Logo Float */}
        <motion.div
          initial={{ opacity: 0, y: -25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-6 relative group"
        >
          <div className="absolute inset-0 bg-brand-light/25 rounded-full blur-xl group-hover:opacity-60 transition-opacity" />
          <Logo size="lg" withText={true} className="relative z-10 filter drop-shadow-[0_0_15px_rgba(74,15,33,0.5)] group-hover:scale-105 duration-500 transition-all" />
        </motion.div>

        {/* Header Typography */}
        <div className="text-center max-w-4xl space-y-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-none border-l-2 border-r-2 border-gold bg-brand-medium/40 border-y border-brand-light/30 backdrop-blur-md"
          >
            <span className="w-2 h-2 bg-rose-500 rounded-full animate-ping" />
            <span className="font-mono text-[10px] uppercase tracking-widest text-[#ebd07b] font-black glitch-accent-hover">
              THE SOVEREIGN ASSEMBLY // DELHI UNIVERSITY
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl sm:text-6xl lg:text-7xl font-serif font-extrabold text-cream tracking-tight leading-none"
          >
            EDOPIA <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold via-gold-light to-gold font-serif text-shadow-gold">MUN</span> 2026
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-sm sm:text-base text-cream/70 font-sans max-w-2xl mx-auto leading-relaxed"
          >
            Where classic diplomacy meets cutting-edge strategic governance. Formulate international treaties, execute crisis drafts, and debate sovereign safety at our exclusive central campus platform.
          </motion.p>
        </div>

        {/* Quick Details Cards with Edgy Cyber Borders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8 w-full max-w-lg"
        >
          <div className="flex items-center gap-3 bg-card-dark/70 border border-brand-light/40 px-4 py-3 rounded-none backdrop-blur-md tech-corners cyber-border transition-all duration-300">
            <Calendar className="w-5 h-5 text-gold filter drop-shadow-[0_0_5px_rgba(212,175,55,0.5)]" />
            <div className="text-left">
              <p className="text-[9px] uppercase font-mono tracking-widest font-bold text-gold">Conference Dates</p>
              <p className="text-xs sm:text-sm font-bold text-cream">4 - 5 July, 2026</p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-card-dark/70 border border-brand-light/40 px-4 py-3 rounded-none backdrop-blur-md tech-corners cyber-border transition-all duration-300">
            <MapPin className="w-5 h-5 text-rose-500 filter drop-shadow-[0_0_5px_rgba(239,68,68,0.5)]" />
            <div className="text-left">
              <p className="text-[9px] uppercase font-mono tracking-widest font-bold text-gold">Event Venue</p>
              <p className="text-xs sm:text-sm font-bold text-cream">Deshbandhu College, DU</p>
            </div>
          </div>
        </motion.div>

        {/* Dynamic Countdown Clock with cyber glow and tech details */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-12 bg-gradient-to-b from-card-dark to-[#120709] border border-brand-light/50 rounded-none p-6 shadow-[0_0_35px_rgba(212,175,55,0.05)] relative max-w-xl w-full overflow-hidden tech-corners cyber-border"
        >
          {/* Active scanline beam */}
          <div className="scanline-laser" />

          {/* Subtle tech coordinates */}
          <div className="absolute top-2 left-3 font-mono text-[8px] text-cream/20 tracking-widest">
            SYS.LOC // 28.5244 N, 77.2536 E (Deshbandhu Geocoordinates)
          </div>

          {/* Subtle logo accent on clock */}
          <div className="absolute right-4 top-4 opacity-10 pointer-events-none">
            <Logo size="sm" withText={false} className="animate-spin-slow text-gold opacity-30" />
          </div>

          <p className="text-center font-mono text-xs uppercase tracking-widest text-gold font-bold mb-5 mt-2 flex items-center justify-center gap-2">
            <span className="text-rose-500 animate-pulse">//</span> 
            CONFERENCE COMMENCEMENT COUNTDOWN 
            <span className="text-rose-500 animate-pulse">//</span>
          </p>

          <div className="grid grid-cols-4 gap-2 sm:gap-4 text-center relative z-10">
            {Object.entries(timeLeft).map(([unit, value]) => (
              <div 
                key={unit} 
                className="bg-brand-dark/80 border border-brand-light/40 rounded-none p-3 sm:py-4 relative hover:border-gold/60 transition-all duration-300 group hover:scale-[1.04]"
              >
                {/* Micro bracket decoration */}
                <span className="absolute -top-1 -left-1 text-[8px] text-gold/40 group-hover:text-gold transition-colors font-mono font-bold">[</span>
                <span className="absolute -bottom-1 -right-1 text-[8px] text-gold/40 group-hover:text-gold transition-colors font-mono font-bold">]</span>
                
                <span className="block text-2xl sm:text-4xl font-mono font-black text-[#ebd07b] tracking-wider text-shadow-gold">
                  {String(value).padStart(2, "0")}
                </span>
                <span className="block text-[8px] sm:text-[9px] uppercase font-mono tracking-widest text-cream/60 mt-1 font-bold group-hover:text-gold transition-colors">
                  {unit}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* CTA Button Block - Edgy Rectangular Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-12 flex flex-col sm:flex-row items-center gap-4"
        >
          <button
            onClick={() => setActiveTab("dashboard")}
            className="relative group overflow-hidden bg-gradient-to-r from-gold to-[#e0be4e] text-brand-dark px-8 py-4 rounded-none font-bold font-sans tracking-widest uppercase text-xs shadow-[0_0_20px_rgba(212,175,55,0.2)] hover:shadow-[0_0_30px_rgba(212,175,55,0.45)] hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-2 border border-gold-light"
          >
            {/* Shimmer line effect on hover */}
            <span className="absolute inset-0 w-full h-full bg-white/20 transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
            <span>{registeredUser ? "Go to Delegate Portal" : "Pre-Register Your Seats"}</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform text-brand-dark" />
          </button>
          
          <button
            onClick={() => setActiveTab("committees")}
            className="relative group overflow-hidden px-8 py-4 bg-brand-dark/40 border border-brand-light text-cream rounded-none font-bold font-sans tracking-widest uppercase text-xs hover:bg-brand-medium/30 hover:border-gold/60 hover:text-gold hover:scale-105 active:scale-95 transition-all duration-300"
          >
            Browse Committees
          </button>

          <a
            href="https://docs.google.com/spreadsheets/d/1FpbfnksRLDst4WKa9LNnMfy7lgPZ3sGx/edit?usp=drivesdk&ouid=106642394536458064828&rtpof=true&sd=true"
            target="_blank"
            rel="noopener noreferrer"
            className="relative group overflow-hidden px-8 py-4 bg-rose-950/20 border border-rose-500/25 text-cream rounded-none font-bold font-sans tracking-widest uppercase text-xs hover:bg-rose-900/40 hover:border-gold/60 hover:text-gold hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-1.5"
          >
            <span>Allotment Matrix</span>
            <ChevronRight className="w-4 h-4 text-cream group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </section>

      {/* Marquee Ticker */}
      <div id="ticker" className="bg-brand-dark/90 py-2.5 border-y border-brand-light/40 overflow-hidden whitespace-nowrap relative z-10">
        <div className="inline-block animate-marquee font-mono text-[11px] text-gold-light/90 font-bold tracking-widest uppercase">
          ✦ DESHBANDHU COLLEGE, DU ANNOUNCED AS EXCLUSIVE HOST VENUE // ✦ TOTAL CASH PRIZE POOL EXCEEDS ₹40,000 ✦ ONLINE REGISTRATIONS LIVE ON GLOBAL DASHBOARD ✦ ALL RESIDENCY & CHAIR ALLOTMENTS COMMENCED ✦ SIX CRITICAL CRISIS COUNCILS SIMULATED ✦ PREPARE SECURE BRIEFCASE DOSSIERS // ✦
        </div>
      </div>

      {/* Stats Matrix */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-gradient-to-br from-card-dark to-[#13070a] border border-brand-light/30 rounded-none p-6 relative overflow-hidden group tech-corners cyber-border transition-all duration-300 transform hover:-translate-y-1 block hover:shadow-[0_10px_25px_rgba(131,32,64,0.15)]"
            >
              {/* Grid overlay */}
              <div className="absolute inset-0 scanline-grid opacity-20 pointer-events-none" />
              
              <div className="absolute right-4 bottom-4 opacity-10 pointer-events-none group-hover:scale-115 group-hover:text-gold group-hover:opacity-20 transition-all duration-500">
                <stat.icon className="w-16 h-16 text-cream" />
              </div>

              <div className="flex items-center gap-1.5 mb-2 relative z-10">
                <span className="w-1.5 h-1.5 bg-rose-500 animate-pulse rounded-full" />
                <p className="font-mono text-[10px] sm:text-xs text-gold font-bold tracking-widest uppercase">
                  {stat.label}
                </p>
              </div>

              <div className="flex items-baseline gap-2 relative z-10">
                <span className="text-3xl sm:text-4xl font-serif font-black text-cream tracking-tight group-hover:text-gold-light transition-colors">
                  {stat.value}
                </span>
                <span className="text-xs sm:text-sm font-mono text-cream/70 font-semibold uppercase tracking-wider">
                  {stat.suffix}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>


    </div>
  );
}
