import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, User, Award, Bell, Shield } from "lucide-react";
import Logo from "./Logo";
import { RegistrationData } from "../types";

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  registeredUser: RegistrationData | null;
}

export default function Navigation({ activeTab, setActiveTab, registeredUser }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hoveredTab, setHoveredTab] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "Overview" },
    { id: "committees", label: "Committees" },
    { id: "matrix", label: "Country Matrix", href: "https://docs.google.com/spreadsheets/d/1FpbfnksRLDst4WKa9LNnMfy7lgPZ3sGx/edit?usp=drivesdk&ouid=106642394536458064828&rtpof=true&sd=true", external: true },
    { id: "dashboard", label: registeredUser ? "Delegate Portal" : "Register Now" },
    { id: "schedule", label: "Schedule" },
    { id: "guide", label: "Guide & FAQ" },
  ];

  const handleTabClick = (tabId: string) => {
    const matched = navItems.find((item) => item.id === tabId);
    if (matched && matched.external && matched.href) {
      window.open(matched.href, "_blank", "noopener,noreferrer");
      setIsOpen(false);
      return;
    }
    setActiveTab(tabId);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <nav
      id="main-navigation-bar"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? "backdrop-blur-lg bg-slate-bg/90 border-b border-brand-light/20 py-2 shadow-[0_10px_30px_rgba(0,0,0,0.8)]"
          : "bg-transparent py-4"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Name */}
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => handleTabClick("home")}
          >
            <Logo size="sm" withText={false} />
            <div className="flex flex-col">
              <span className="font-serif font-bold text-lg leading-tight tracking-wide text-cream group-hover:text-gold transition-colors duration-200">
                EDOPIA
              </span>
              <span className="font-mono text-[10px] text-gold tracking-widest leading-none font-bold uppercase">
                mun 2026
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              const isAccent = item.id === "dashboard" && !registeredUser;
              return (
                <div
                  key={item.id}
                  className="relative px-3 py-2 cursor-pointer"
                  onMouseEnter={() => setHoveredTab(item.id)}
                  onMouseLeave={() => setHoveredTab(null)}
                  onClick={() => handleTabClick(item.id)}
                >
                  {/* Floating Background Pill for hover */}
                  <AnimatePresence>
                    {hoveredTab === item.id && (
                      <motion.div
                        layoutId="navHoverPill"
                        className="absolute inset-0 rounded-lg bg-brand-light/10 z-0"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ type: "spring", stiffness: 350, damping: 30 }}
                      />
                    )}
                  </AnimatePresence>

                  {/* Active Indicator Underline */}
                  {isActive && (
                    <motion.div
                      layoutId="navActiveLine"
                      className="absolute bottom-0 left-2 right-2 h-[2px] bg-gold z-10"
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                    />
                  )}

                  <span
                    className={`relative z-10 font-sans text-sm font-medium tracking-wide transition-colors duration-200 ${
                      isActive
                        ? "text-gold"
                        : isAccent
                        ? "text-brand-dark px-4 py-1.5 bg-gold rounded-md font-bold shadow-[0_0_10px_rgba(212,175,55,0.4)] hover:bg-gold-light hover:scale-105 transition-transform"
                        : "text-cream/80 hover:text-cream"
                    }`}
                  >
                    {item.label}
                  </span>
                </div>
              );
            })}

            {/* Quick Registered User Indicator */}
            {registeredUser && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="ml-4 pl-4 border-l border-brand-light/30 flex items-center gap-2"
              >
                <div
                  onClick={() => handleTabClick("dashboard")}
                  className="flex items-center gap-2 bg-gradient-to-r from-brand-medium/50 to-brand-light/30 border border-brand-light/50 px-3 py-1.5 rounded-full cursor-pointer hover:border-gold/50 transition-colors group"
                >
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                  <User className="w-4 h-4 text-gold group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-xs text-cream font-medium max-w-[80px] truncate">
                    {registeredUser.fullName.split(" ")[0]}
                  </span>
                </div>
              </motion.div>
            )}
          </div>

          {/* Mobile menu toggle */}
          <div className="md:hidden flex items-center gap-3">
            {registeredUser && (
              <div 
                onClick={() => handleTabClick("dashboard")}
                className="flex items-center gap-1 bg-brand-medium/40 border border-brand-light/40 px-2.5 py-1 rounded-full text-xs font-mono text-gold cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>Portal</span>
              </div>
            )}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-cream hover:bg-brand-light/10 hover:text-gold transition-colors"
              aria-label="Toggle navigation menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer with dynamic animations */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-slate-bg border-b border-brand-light/30 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {navItems.map((item) => {
                const isActive = activeTab === item.id;
                const isAccent = item.id === "dashboard" && !registeredUser;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabClick(item.id)}
                    className={`w-full text-left px-4 py-3 rounded-lg text-base font-semibold tracking-wide transition-all ${
                      isActive
                        ? "bg-brand/40 text-gold border-l-4 border-gold pl-3"
                        : isAccent
                        ? "bg-gold text-brand-dark font-extrabold shadow-[0_4px_12px_rgba(212,175,55,0.3)] text-center mt-3"
                        : "text-cream/85 hover:bg-brand-light/10 hover:text-cream"
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
