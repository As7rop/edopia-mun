import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  User, School, Keyboard, Trash2, CheckCircle2, ChevronRight, AlertCircle, 
  CreditCard, Award, FileText, Download, Calendar, ClipboardCheck, ArrowLeft, RefreshCw,
  Sparkles, ShieldCheck, Terminal, Check, Lock, Fingerprint, Globe
} from "lucide-react";
import { RegistrationData, Committee } from "../types";
import { COMMITTEES } from "../data";
import Logo from "./Logo";

interface DashboardSectionProps {
  registeredUser: RegistrationData | null;
  setRegisteredUser: (data: RegistrationData | null) => void;
  selectedCommitteeId: string | null;
  setSelectedCommitteeId: (id: string | null) => void;
}

export default function DashboardSection({ 
  registeredUser, setRegisteredUser, selectedCommitteeId, setSelectedCommitteeId 
}: DashboardSectionProps) {
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formMode, setFormMode] = useState<"official" | "simulation">("official");
  
  // Registration Form State
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    institution: "",
    classOrYear: "",
    experience: "",
    delegationType: "Single" as "Single" | "Double" | "Team",
    doublePartnerName: "",
    doublePartnerEmail: "",
    partner2Name: "",
    partner2Email: "",
    partner3Name: "",
    partner3Email: "",
    partner4Name: "",
    partner4Email: "",
    committeePreference1: selectedCommitteeId || "unga",
    portfolioPreference1: "",
    committeePreference2: "aippm",
    portfolioPreference2: "",
    committeePreference3: "lok-sabha",
    portfolioPreference3: "",
    paymentReceiptNumber: ""
  });

  const [paymentPending, setPaymentPending] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Prep Checklist State
  const [prepChecklist, setPrepChecklist] = useState<Record<string, boolean>>({
    studyGuides: true,
    rulesOfProcedure: true,
    crisisSimBrief: false,
    diplomaticPleadings: false
  });

  // Position Paper State
  const [positionPaper, setPositionPaper] = useState<{ name: string; size: string; date: string } | null>(null);
  const [uploadingPaper, setUploadingPaper] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // Auto fill committee from other tabs if selected
  useEffect(() => {
    if (selectedCommitteeId) {
      setFormData(prev => ({
        ...prev,
        committeePreference1: selectedCommitteeId
      }));
    }
  }, [selectedCommitteeId]);

  // Handle Input Changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors(prev => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  // Pre-fill Demo Data Helper for Instant Testing/Review
  const handlePreFill = () => {
    setFormData({
      fullName: "Saiyam Jain",
      email: "saiyamjain842@gmail.com",
      phone: "+91 98765 20260",
      institution: "Delhi Public School, R.K. Puram",
      classOrYear: "Class XI (Humanities)",
      experience: "Served as Delegate for France in UNGA at DPSMUN 2025. Participated in multiple local mock parliament debates with an interest in cyber intelligence governance, state aerospace treaties, and corporate sporting policies.",
      delegationType: "Single",
      doublePartnerName: "",
      doublePartnerEmail: "",
      committeePreference1: selectedCommitteeId || "unga",
      portfolioPreference1: "United States of America",
      committeePreference2: "aippm",
      portfolioPreference2: "Narendra Modi (BJP)",
      committeePreference3: "lok-sabha",
      portfolioPreference3: "New Delhi Constituency (BJP)",
      paymentReceiptNumber: "TXN-EDOPIA-2026-9051"
    });
    setStep(3); // Instant leap to step 3 checkout
    setErrors({});
  };

  // Step Validation
  const validateStep = (currentStep: number) => {
    const newErrors: Record<string, string> = {};
    if (currentStep === 1) {
      if (!formData.fullName.trim()) newErrors.fullName = "Full Name is required";
      if (!formData.email.trim() || !formData.email.includes("@")) newErrors.email = "Valid email is required";
      if (!formData.phone.trim() || formData.phone.length < 8) newErrors.phone = "Valid contact number is required";
      if (!formData.institution.trim()) newErrors.institution = "School/College name is required";
      if (!formData.classOrYear.trim()) newErrors.classOrYear = "Grade, class or academic year is required";
    } else if (currentStep === 2) {
      if (!formData.portfolioPreference1.trim()) newErrors.portfolioPreference1 = "First preference country/member representation is required";
      if (formData.committeePreference1 === "ipl") {
        if (!formData.partner2Name.trim()) newErrors.partner2Name = "Teammate 2 Name is required";
        if (!formData.partner2Email.trim() || !formData.partner2Email.includes("@")) {
          newErrors.partner2Email = "Valid teammate 2 email is required";
        }
        if (!formData.partner3Name.trim()) newErrors.partner3Name = "Teammate 3 Name is required";
        if (!formData.partner3Email.trim() || !formData.partner3Email.includes("@")) {
          newErrors.partner3Email = "Valid teammate 3 email is required";
        }
        if (!formData.partner4Name.trim()) newErrors.partner4Name = "Teammate 4 Name is required";
        if (!formData.partner4Email.trim() || !formData.partner4Email.includes("@")) {
          newErrors.partner4Email = "Valid teammate 4 email is required";
        }
      }
    } else if (currentStep === 3) {
      if (!formData.paymentReceiptNumber.trim() || formData.paymentReceiptNumber.length < 6) {
        newErrors.paymentReceiptNumber = "Please enter a valid Transaction ID / Reference Code";
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(step)) {
      setStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    setStep(prev => prev - 1);
  };

  // Perform Simulated Payment Validation
  const handlePaymentSubmit = () => {
    if (!validateStep(3)) return;
    setPaymentPending(true);
    
    setTimeout(() => {
      setPaymentPending(false);
      setPaymentSuccess(true);
      
      // Auto allotment: Confirms allotment based on their preference 1!
      const finalCommittee = COMMITTEES.find(c => c.id === formData.committeePreference1) || COMMITTEES[2];
      const finalPortfolio = formData.portfolioPreference1 || "Delegated Republic";

      const registration: RegistrationData = {
        id: `ED-2026-${Math.floor(10000 + Math.random() * 90000)}`,
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        institution: formData.institution,
        classOrYear: formData.classOrYear,
        experience: formData.experience || "First-time delegate seeking intensive training.",
        delegationType: formData.committeePreference1 === "ipl" ? "Team" : "Single",
        partner2Name: formData.committeePreference1 === "ipl" ? formData.partner2Name : undefined,
        partner2Email: formData.committeePreference1 === "ipl" ? formData.partner2Email : undefined,
        partner3Name: formData.committeePreference1 === "ipl" ? formData.partner3Name : undefined,
        partner3Email: formData.committeePreference1 === "ipl" ? formData.partner3Email : undefined,
        partner4Name: formData.committeePreference1 === "ipl" ? formData.partner4Name : undefined,
        partner4Email: formData.committeePreference1 === "ipl" ? formData.partner4Email : undefined,
        committeePreference1: formData.committeePreference1,
        portfolioPreference1: formData.portfolioPreference1,
        committeePreference2: formData.committeePreference2,
        portfolioPreference2: formData.portfolioPreference2,
        committeePreference3: formData.committeePreference3,
        portfolioPreference3: formData.portfolioPreference3,
        paymentReceiptNumber: formData.paymentReceiptNumber,
        isApproved: true,
        allottedCommittee: finalCommittee.id,
        allottedPortfolio: finalPortfolio,
        createdAt: new Date().toLocaleDateString()
      };

      setRegisteredUser(registration);
      localStorage.setItem("edopia_mun_registration", JSON.stringify(registration));
      setSelectedCommitteeId(null);
    }, 2500);
  };

  // Cancel/Reset Registration (Allows evaluating different flows)
  const handleResetRegistration = () => {
    if (window.confirm("Are you sure you want to release your allocation portfolio? This will remove your mock credentials.")) {
      setRegisteredUser(null);
      localStorage.removeItem("edopia_mun_registration");
      setPositionPaper(null);
      setStep(1);
      setFormData({
        fullName: "",
        email: "",
        phone: "",
        institution: "",
        classOrYear: "",
        experience: "",
        delegationType: "Single" as "Single" | "Double" | "Team",
        doublePartnerName: "",
        doublePartnerEmail: "",
        partner2Name: "",
        partner2Email: "",
        partner3Name: "",
        partner3Email: "",
        partner4Name: "",
        partner4Email: "",
        committeePreference1: "unga",
        portfolioPreference1: "",
        committeePreference2: "aippm",
        portfolioPreference2: "",
        committeePreference3: "lok-sabha",
        portfolioPreference3: "",
        paymentReceiptNumber: ""
      });
    }
  };

  // Simulated Position Paper upload logic
  const triggerPaperUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setUploadingPaper(true);
      setUploadProgress(0);

      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              setUploadingPaper(false);
              setPositionPaper({
                name: file.name,
                size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
                date: new Date().toLocaleDateString()
              });
            }, 500);
            return 100;
          }
          return prev + 20;
        });
      }, 100);
    }
  };

  const feeAmount = formData.committeePreference1 === "ipl" ? 5000 : 1500;
  const allottedCommObj = COMMITTEES.find(c => c.id === registeredUser?.allottedCommittee);
  const activeFirstPreferenceCommittee = COMMITTEES.find(c => c.id === formData.committeePreference1);

  return (
    <div id="dashboard-section-wrapper" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      
      {!registeredUser ? (
        <div id="registration-portal-wrapper" className="space-y-6 max-w-5xl mx-auto">
          
          {/* Diagnostic Stats Header with Form Selection Mode */}
          <div className="flex flex-col lg:flex-row justify-between items-stretch lg:items-center p-4 bg-[#140608] border border-brand-light/25 rounded-2xl gap-4 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
              <div className="text-left font-mono">
                <span className="text-xs text-gold font-bold">EDOPIA REGISTER CORE</span>
                <span className="text-[10px] text-cream/40 block">CHOOSE PREFERRED REGISTRATION PIPELINE // ONLINE READY</span>
              </div>
            </div>

            {/* Dynamic Interactive Mode Selector and Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <div className="flex p-0.5 bg-brand-dark/95 border border-brand-light/20 rounded-xl gap-0.5 animate-fade-in">
                <button
                  type="button"
                  onClick={() => setFormMode("official")}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg font-mono text-[9.5px] uppercase font-bold transition-all cursor-pointer ${
                    formMode === "official"
                      ? "bg-gold text-brand-dark shadow-[0_0_10px_rgba(212,175,55,0.4)]"
                      : "text-cream/60 hover:text-cream hover:bg-brand-light/10"
                  }`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full ${formMode === "official" ? "bg-brand-dark animate-pulse" : "bg-emerald-400 animate-pulse"}`} />
                  <span>[01] Official Form</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => setFormMode("simulation")}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg font-mono text-[9.5px] uppercase font-bold transition-all cursor-pointer ${
                    formMode === "simulation"
                      ? "bg-[#ebd07b] text-brand-dark shadow-[0_0_10px_rgba(235,208,123,0.4)]"
                      : "text-cream/60 hover:text-cream hover:bg-brand-light/10"
                  }`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full ${formMode === "simulation" ? "bg-brand-dark" : "bg-gold"}`} />
                  <span>[02] Badge Simulator</span>
                </button>
              </div>

              {/* Prefill helper strictly for Simulator mode */}
              {formMode === "simulation" && (
                <button
                  onClick={handlePreFill}
                  type="button"
                  className="flex items-center justify-center gap-1.5 px-3 py-1.5 bg-gold/10 border border-gold/40 text-gold hover:bg-gold hover:text-brand-dark transition-all duration-300 rounded font-mono text-[10px] uppercase font-bold cursor-pointer"
                  title="Populate test data & fast track to validation screen"
                >
                  <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                  <span>[⚡ Auto Prep]</span>
                </button>
              )}

              <a
                href="https://docs.google.com/forms/d/e/1FAIpQLScJdYAMWyfFCh4aqVLViLT8k3oN4jpCyjDeItdq96p0Q9TDWw/viewform?utm_source=ig&utm_medium=social&utm_content=link_in_bio"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 px-3.5 py-1.5 bg-brand-light/10 border border-brand-light/40 text-cream/70 hover:text-white rounded font-mono text-[9.5px] uppercase hover:bg-brand-light/20 transition-all font-semibold"
                title="Open fallback external sheets form"
              >
                <span>External Sheets Form</span>
                <Globe className="w-3 h-3" />
              </a>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {formMode === "official" ? (
              /* GOOGLE FORM DIRECT STREAM PANEL */
              <motion.div
                key="official-form"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="bg-gradient-to-b from-card-dark to-[#0f0406] border border-gold/30 rounded-3xl overflow-hidden shadow-2xl relative text-left"
              >
                {/* Scanline laser scrolling bar */}
                <div className="scanline-laser" />

                {/* Cyber Header Indicators */}
                <div className="bg-[#180608] border-b border-brand-light/25 p-5 pl-7 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-left">
                  <div className="flex items-center gap-3">
                    <Logo size="sm" withText={false} />
                    <div>
                      <h4 className="font-serif font-extrabold text-cream text-lg">Official Delegate Registry</h4>
                      <p className="font-mono text-[9px] text-[#ebd07b] tracking-wider font-black uppercase">EDOPIA MUN 2026 // SECURE DIGITAL CHANNEL</p>
                    </div>
                  </div>
                  
                  {/* Flashing Online Status Indicator */}
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded font-mono text-[9px] text-emerald-400 tracking-wider uppercase font-bold">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                    STREAM: ONLINE
                  </div>
                </div>

                {/* Telemetry metadata bars */}
                <div className="grid grid-cols-2 md:grid-cols-4 border-b border-brand-light/15 bg-brand-dark/30 divide-y sm:divide-y-0 sm:gap-4 font-mono text-[8.5px] text-gold/55 tracking-wider text-left p-3.5 pl-6">
                  <div>PORT: <span className="text-emerald-400 font-bold">SSL_3000 // SECURE</span></div>
                  <div>ID: <span className="text-cream font-bold">EDOPIA_FORM_STREAM</span></div>
                  <div>AGENCY: <span className="text-rose-400 font-bold">UN_SECRETARIAT</span></div>
                  <div>STATUS: <span className="text-[#ebd07b] animate-pulse font-bold">LIVE SYNC READY</span></div>
                </div>

                {/* Secure instructions and external fallback access */}
                <div className="p-4 sm:p-5 bg-amber-500/5 border-b border-brand-light/15 text-xs text-cream/70 leading-relaxed text-left flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <p>
                    Please complete the official registration form directly inside the secure frame below. If on a restricted browser or mobile screen, direct links can be triggered externally.
                  </p>
                  <a
                    href="https://docs.google.com/forms/d/e/1FAIpQLScJdYAMWyfFCh4aqVLViLT8k3oN4jpCyjDeItdq96p0Q9TDWw/viewform?utm_source=ig&utm_medium=social&utm_content=link_in_bio"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="shrink-0 flex items-center justify-center gap-1.5 border border-gold/40 px-3.5 py-1.5 rounded-lg text-[10px] font-mono uppercase bg-gold/10 text-gold font-bold hover:bg-gold hover:text-brand-dark transition-all duration-300"
                  >
                    <span>Launch Form Link</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </a>
                </div>

                {/* Embedded Frame wrapper */}
                <div className="relative bg-[#ffffff] sm:p-1 max-h-[1050px] overflow-y-auto select-auto">
                  <iframe
                    src="https://docs.google.com/forms/d/e/1FAIpQLScJdYAMWyfFCh4aqVLViLT8k3oN4jpCyjDeItdq96p0Q9TDWw/viewform?embedded=true"
                    width="100%"
                    height="980"
                    frameBorder="0"
                    marginHeight={0}
                    marginWidth={0}
                    className="w-full border-0 select-auto bg-white rounded-b-2xl"
                    title="Official Edopia MUN 2026 Delegate Registration Form"
                  >
                    Loading official form streams...
                  </iframe>
                </div>

                {/* Flashing Footer warning ribbon */}
                <div className="bg-[#120508] border-t border-brand-light/25 p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
                  <span className="font-mono text-[9px] text-[#ebd07b]/60 uppercase tracking-wider">
                    SYSTEMS VERIFIED BY EDOPIA MUN SECRETARIAT © 2026
                  </span>
                  <button
                    onClick={() => setFormMode("simulation")}
                    className="font-mono text-[9.5px] uppercase tracking-wider text-cream/75 hover:text-gold flex items-center gap-1.5 transition-colors font-bold cursor-pointer"
                  >
                    <span>Proceed to Interactive Badge Simulator</span>
                    <ChevronRight className="w-3.5 h-3.5 text-gold-light" />
                  </button>
                </div>
              </motion.div>
            ) : (
              /* Unified Web Native Registration Stage */
              <motion.div
                key="simulation-form"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="bg-gradient-to-b from-card-dark to-[#0f0406] border border-gold/30 rounded-3xl overflow-hidden shadow-2xl relative"
              >
                {/* Scanline laser scrolling bar for cyber visual effect */}
                <div className="scanline-laser" />

            {/* Cyber Header Indicators */}
            <div className="bg-[#180608] border-b border-brand-light/25 p-5 pl-7 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-left">
              <div className="flex items-center gap-3">
                <Logo size="sm" withText={false} />
                <div>
                  <h4 className="font-serif font-extrabold text-cream text-lg">Official Web-Native Registry</h4>
                  <p className="font-mono text-[9px] text-[#ebd07b] tracking-wider font-black uppercase">EDOPIA MUN 2026 // SECURE DIGITAL CHANNEL</p>
                </div>
              </div>
              
              {/* Responsive Progress Indicators */}
              <div className="flex gap-1.5 font-mono text-[9.5px]">
                <div className="px-2 py-1 bg-[#120508]/80 border border-brand-light/35 text-gold font-bold">
                  STEP: {step}/3
                </div>
                <div className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold uppercase tracking-wider">
                  System: Online
                </div>
              </div>
            </div>

            {/* Cyber Progress Indicator Path */}
            <div className="bg-brand-dark/40 border-b border-brand-light/15 p-4 pl-6 pr-6">
              <div className="relative">
                {/* Horizontal progress bar background */}
                <div className="absolute top-1/2 left-0 w-full h-[2px] bg-brand-light/20 -translate-y-1/2 rounded" />
                {/* Active progress value */}
                <div 
                  className="absolute top-1/2 left-0 h-[2px] bg-gold -translate-y-1/2 rounded transition-all duration-500 shadow-[0_0_8px_#d4af37]"
                  style={{ width: `${((step - 1) / 2) * 100}%` }}
                />
                
                {/* Step indicator points */}
                <div className="relative flex justify-between">
                  {[
                    { num: 1, id: "01_IDENT", title: "Identity Profile" },
                    { num: 2, id: "02_ALLOC", title: "Senate Assembly" },
                    { num: 3, id: "03_TREAS", title: "Clearing Lodge" }
                  ].map((s) => (
                    <button
                      key={s.num}
                      onClick={() => {
                        // Allow backwards navigation directly by clicking completed steps
                        if (s.num < step) setStep(s.num);
                      }}
                      disabled={s.num >= step}
                      className="flex flex-col items-center outline-none group cursor-pointer disabled:cursor-not-allowed"
                    >
                      <div 
                        className={`w-7 h-7 rounded-full font-mono text-[10px] font-bold flex items-center justify-center border transition-all duration-300 relative z-10 ${
                          step >= s.num 
                            ? "bg-[#1d060a] border-gold text-gold shadow-[0_0_10px_rgba(212,175,55,0.4)]" 
                            : "bg-brand-dark/80 border-brand-light/30 text-cream/40"
                        }`}
                      >
                        {step > s.num ? (
                          <Check className="w-3.5 h-3.5 text-gold-light" />
                        ) : (
                          <span>{s.num}</span>
                        )}
                      </div>
                      <span className="hidden sm:block font-mono text-[8px] uppercase font-bold tracking-widest mt-1.5 text-cream/60 group-hover:text-gold duration-200">
                        {s.id}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Layout Wrapper */}
            <div className="pl-4 pr-4 py-8">
              
              {/* Left Side: Standard forms with snappy transitions */}
              <div className="px-3 sm:px-6 space-y-6 pb-4">
                <AnimatePresence mode="wait">
                  
                  {/* Step 1: Identity Calibration */}
                  {step === 1 && (
                    <motion.div
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-5 text-left"
                    >
                      <div className="border-b border-brand-light/15 pb-4.5">
                        <span className="font-mono text-[9px] uppercase tracking-widest text-[#ebd07b] font-black block">SESSION CONFIGURATION // PROTOCOL_01</span>
                        <h4 className="font-serif font-extrabold text-cream text-xl flex items-center gap-2 mt-1">
                          <User className="w-5.5 h-5.5 text-gold" /> Personal Identity Coordinates
                        </h4>
                        <p className="text-xs text-cream/60 mt-1">Provide authentic communication vectors for academic delegation logging.</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
                        <div>
                          <label className="block font-mono text-[10px] uppercase text-gold font-bold mb-1.5 tracking-wider">
                            Full Name <span className="text-rose-400">*</span>
                          </label>
                          <div className="relative group">
                            <input
                              type="text"
                              name="fullName"
                              value={formData.fullName}
                              onChange={handleInputChange}
                              placeholder="e.g., Saiyam Jain"
                              className={`w-full bg-brand-dark/40 border p-3 pl-3 rounded-xl border-brand-light/35 text-cream placeholder-cream/35 focus:border-gold focus:ring-1 focus:ring-gold/30 outline-none transition-all duration-300 ${errors.fullName ? "border-rose-500/70" : ""}`}
                            />
                            <Fingerprint className="absolute right-3.5 top-3.5 w-4.5 h-4.5 text-cream/20 group-focus-within:text-gold/40 transition-colors" />
                          </div>
                          {errors.fullName && (
                            <span className="text-[10px] text-rose-400 mt-1 flex items-center gap-1 font-mono tracking-wide">
                              <AlertCircle className="w-3 h-3 shrink-0" />{errors.fullName}
                            </span>
                          )}
                        </div>

                        <div>
                          <label className="block font-mono text-[10px] uppercase text-gold font-bold mb-1.5 tracking-wider">
                            Personal Email Address <span className="text-rose-400">*</span>
                          </label>
                          <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="delegate@domain.com"
                            className={`w-full bg-brand-dark/40 border p-3 rounded-xl border-brand-light/35 text-cream placeholder-cream/35 focus:border-gold focus:ring-1 focus:ring-gold/30 outline-none transition-all duration-300 ${errors.email ? "border-rose-500/70" : ""}`}
                          />
                          {errors.email && (
                            <span className="text-[10px] text-rose-400 mt-1 flex items-center gap-1 font-mono tracking-wide">
                              <AlertCircle className="w-3 h-3 shrink-0" />{errors.email}
                            </span>
                          )}
                        </div>

                        <div>
                          <label className="block font-mono text-[10px] uppercase text-gold font-bold mb-1.5 tracking-wider">
                            Direct Contact Number <span className="text-rose-400">*</span>
                          </label>
                          <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="e.g., +91 98765 43210"
                            className={`w-full bg-brand-dark/40 border p-3 rounded-xl border-brand-light/35 text-cream placeholder-cream/35 focus:border-gold focus:ring-1 focus:ring-gold/30 outline-none transition-all duration-300 ${errors.phone ? "border-rose-500/70" : ""}`}
                          />
                          <p className="text-[9px] text-[#ebd07b]/50 mt-1 pl-1">WhatsApp enabled preferred for docket notifications.</p>
                          {errors.phone && (
                            <span className="text-[10px] text-rose-400 mt-1 flex items-center gap-1 font-mono tracking-wide">
                              <AlertCircle className="w-3 h-3 shrink-0" />{errors.phone}
                            </span>
                          )}
                        </div>

                        <div>
                          <label className="block font-mono text-[10px] uppercase text-gold font-bold mb-1.5 tracking-wider">
                            Academic Grade / Year / Class <span className="text-rose-400">*</span>
                          </label>
                          <input
                            type="text"
                            name="classOrYear"
                            value={formData.classOrYear}
                            onChange={handleInputChange}
                            placeholder="e.g., Class XII (Humanities) / B.A. Semester III"
                            className={`w-full bg-brand-dark/40 border p-3 rounded-xl border-brand-light/35 text-cream placeholder-cream/35 focus:border-gold focus:ring-1 focus:ring-gold/30 outline-none transition-all duration-300 ${errors.classOrYear ? "border-rose-500/70" : ""}`}
                          />
                          {errors.classOrYear && (
                            <span className="text-[10px] text-rose-400 mt-1 flex items-center gap-1 font-mono tracking-wide">
                              <AlertCircle className="w-3 h-3 shrink-0" />{errors.classOrYear}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="pt-2">
                        <label className="block font-mono text-[10px] uppercase text-gold font-bold mb-1.5 tracking-wider">
                          Represented Educational Institution <span className="text-rose-400">*</span>
                        </label>
                        <div className="relative group">
                          <input
                            type="text"
                            name="institution"
                            value={formData.institution}
                            onChange={handleInputChange}
                            placeholder="e.g., Modern Public High School, New Delhi"
                            className={`w-full bg-brand-dark/40 border p-3 pl-10 rounded-xl border-brand-light/35 text-cream placeholder-cream/35 focus:border-gold focus:ring-1 focus:ring-gold/30 outline-none transition-all duration-300 ${errors.institution ? "border-rose-500/70" : ""}`}
                          />
                          <School className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-cream/20 group-focus-within:text-gold/40 transition-colors" />
                        </div>
                        {errors.institution && (
                          <span className="text-[10px] text-rose-400 mt-1 flex items-center gap-1 font-mono tracking-wide">
                            <AlertCircle className="w-3 h-3 shrink-0" />{errors.institution}
                          </span>
                        )}
                      </div>
                    </motion.div>
                  )}

                  {/* Step 2: Assemblies & Preference Routing (Google form text logic) */}
                  {step === 2 && (
                    <motion.div
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="space-y-5 text-left"
                    >
                      <div className="border-b border-brand-light/15 pb-4">
                        <span className="font-mono text-[9px] uppercase tracking-widest text-[#ebd07b] font-black block">SENATE ROUTING DIRECTIVE // PROTOCOL_02</span>
                        <h4 className="font-serif font-extrabold text-cream text-[#ebd07b] text-xl flex items-center gap-2 mt-1">
                          <School className="w-5.5 h-5.5 text-gold" /> Representation & Assembly Options
                        </h4>
                        <p className="text-xs text-cream/60 mt-1">Configure allocation preferences. Selected assembly details are live-audited in the telemetry advisor.</p>
                      </div>
                      {/* Delegation Scale and Info */}
                      <div className="p-4 rounded-xl border bg-brand-dark/20 border-brand-light/20 text-cream/90">
                        {formData.committeePreference1 === "ipl" ? (
                          <div className="space-y-1 text-left">
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                              <p className="font-mono text-[11px] uppercase tracking-wider font-extrabold text-gold leading-none">IPL Franchise Squad Mode (4-Person Team Required)</p>
                            </div>
                            <p className="text-xs text-cream/70 mt-1 leading-relaxed">
                              IPL committee simulates business franchise auctions and requires exactly <strong>four (4) members per team</strong> to represent the franchise. The discounted collective squad fee is settled at <strong className="text-cream">₹5,000.00</strong> total. Please supply details for your 3 teammate partners below.
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-1 text-left">
                            <div className="flex items-center gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              <p className="font-mono text-[11px] uppercase tracking-wider font-extrabold text-emerald-400 leading-none">Single Delegation Mode</p>
                            </div>
                            <p className="text-xs text-cream/70 mt-1 leading-relaxed">
                              All standard committees operate on an individual basis. You will represent your assigned nation or character on your own. Individual delegation fee is settled at <strong className="text-cream">₹1,500.00</strong>.
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Partners field block for IPL Squad Teammates */}
                      {formData.committeePreference1 === "ipl" && (
                        <div className="space-y-4 bg-brand-medium/20 p-4.5 border border-brand-light/35 rounded-xl text-left">
                          <p className="font-mono text-[10px] uppercase text-gold font-extrabold tracking-wider border-b border-brand-light/10 pb-1.5">
                            IPL franchise teammate registrations (3 required)
                          </p>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {/* Partner 2 */}
                            <div>
                              <label className="block font-mono text-[9.5px] uppercase text-cream/80 font-bold mb-1">Teammate 2 Name</label>
                              <input
                                type="text"
                                name="partner2Name"
                                value={formData.partner2Name || ""}
                                onChange={handleInputChange}
                                placeholder="Teammate 2 Name"
                                className="w-full bg-[#140508] border p-2.5 rounded-lg border-brand-light/40 text-cream focus:border-gold outline-none text-xs"
                              />
                              {errors.partner2Name && <span className="text-[9.5px] text-rose-400 leading-none pl-1 mt-1 block font-mono">{errors.partner2Name}</span>}
                            </div>
                            <div>
                              <label className="block font-mono text-[9.5px] uppercase text-cream/80 font-bold mb-1">Teammate 2 Email</label>
                              <input
                                type="email"
                                name="partner2Email"
                                value={formData.partner2Email || ""}
                                onChange={handleInputChange}
                                placeholder="teammate2@domain.com"
                                className="w-full bg-[#140508] border p-2.5 rounded-lg border-brand-light/40 text-cream focus:border-gold outline-none text-xs"
                              />
                              {errors.partner2Email && <span className="text-[9.5px] text-rose-400 leading-none pl-1 mt-1 block font-mono">{errors.partner2Email}</span>}
                            </div>

                            {/* Partner 3 */}
                            <div>
                              <label className="block font-mono text-[9.5px] uppercase text-cream/80 font-bold mb-1">Teammate 3 Name</label>
                              <input
                                type="text"
                                name="partner3Name"
                                value={formData.partner3Name || ""}
                                onChange={handleInputChange}
                                placeholder="Teammate 3 Name"
                                className="w-full bg-[#140508] border p-2.5 rounded-lg border-brand-light/40 text-cream focus:border-gold outline-none text-xs"
                              />
                              {errors.partner3Name && <span className="text-[9.5px] text-rose-400 leading-none pl-1 mt-1 block font-mono">{errors.partner3Name}</span>}
                            </div>
                            <div>
                              <label className="block font-mono text-[9.5px] uppercase text-cream/80 font-bold mb-1">Teammate 3 Email</label>
                              <input
                                type="email"
                                name="partner3Email"
                                value={formData.partner3Email || ""}
                                onChange={handleInputChange}
                                placeholder="teammate3@domain.com"
                                className="w-full bg-[#140508] border p-2.5 rounded-lg border-brand-light/40 text-cream focus:border-gold outline-none text-xs"
                              />
                              {errors.partner3Email && <span className="text-[9.5px] text-rose-400 leading-none pl-1 mt-1 block font-mono">{errors.partner3Email}</span>}
                            </div>

                            {/* Partner 4 */}
                            <div>
                              <label className="block font-mono text-[9.5px] uppercase text-cream/80 font-bold mb-1">Teammate 4 Name</label>
                              <input
                                type="text"
                                name="partner4Name"
                                value={formData.partner4Name || ""}
                                onChange={handleInputChange}
                                placeholder="Teammate 4 Name"
                                className="w-full bg-[#140508] border p-2.5 rounded-lg border-brand-light/40 text-cream focus:border-gold outline-none text-xs"
                              />
                              {errors.partner4Name && <span className="text-[9.5px] text-rose-400 leading-none pl-1 mt-1 block font-mono">{errors.partner4Name}</span>}
                            </div>
                            <div>
                              <label className="block font-mono text-[9.5px] uppercase text-cream/80 font-bold mb-1">Teammate 4 Email</label>
                              <input
                                type="email"
                                name="partner4Email"
                                value={formData.partner4Email || ""}
                                onChange={handleInputChange}
                                placeholder="teammate4@domain.com"
                                className="w-full bg-[#140508] border p-2.5 rounded-lg border-brand-light/40 text-cream focus:border-gold outline-none text-xs"
                              />
                              {errors.partner4Email && <span className="text-[9.5px] text-rose-400 leading-none pl-1 mt-1 block font-mono">{errors.partner4Email}</span>}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Portfolio priority selects */}
                      <div className="space-y-3.5 bg-brand-dark/30 p-4.5 rounded-xl border border-brand-light/20">
                        <div className="flex justify-between items-center">
                          <p className="font-mono text-[10px] uppercase tracking-wider text-gold font-black">PRIORITY REPRESENTATIVE ASSIGNMENTS</p>
                          <span className="text-[8.5px] font-mono text-cream/40">[ALL_SLOTS_RESERVED]</span>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
                          
                          {/* Prefer 1 */}
                          <div className="p-3 bg-[#110508] rounded-xl border border-brand-light/35 space-y-2 relative">
                            <span className="absolute -top-2 left-3 bg-[#110508] px-1.5 border border-gold/40 text-[8.5px] text-gold font-black">優先 1ST</span>
                            <label className="block text-[9.5px] uppercase text-cream/80 font-bold mb-1 mt-1">Primary Council</label>
                            <select
                              name="committeePreference1"
                              value={formData.committeePreference1}
                              onChange={handleInputChange}
                              className="w-full bg-[#130608] border p-2 rounded-lg border-brand-light/50 text-cream outline-none text-xs font-semibold cursor-pointer"
                            >
                              {COMMITTEES.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                            
                            <label className="block text-[9.5px] uppercase text-cream/80 font-bold mt-2">Portfolio Preference</label>
                            <input
                              type="text"
                              name="portfolioPreference1"
                              placeholder="e.g. United States or Modi"
                              value={formData.portfolioPreference1}
                              onChange={handleInputChange}
                              className={`w-full bg-[#140508]/40 border p-2.5 rounded-lg border-brand-light/30 text-cream text-xs outline-none focus:border-gold placeholder-cream/30 ${errors.portfolioPreference1 ? "border-rose-400" : ""}`}
                            />
                            {errors.portfolioPreference1 && <span className="text-[9.5px] text-rose-400 leading-none block font-mono font-bold mt-1">{errors.portfolioPreference1}</span>}
                          </div>

                          {/* Prefer 2 */}
                          <div className="p-3 bg-[#110508]/60 rounded-xl border border-brand-light/25 space-y-2 relative">
                            <span className="absolute -top-2 left-3 bg-[#110508] px-1.5 border border-brand-light/30 text-[8.5px] text-cream/50 font-bold">2ND CHOICE</span>
                            <label className="block text-[9.5px] uppercase text-cream/80 font-bold mb-1 mt-1">Secondary Council</label>
                            <select
                              name="committeePreference2"
                              value={formData.committeePreference2}
                              onChange={handleInputChange}
                              className="w-full bg-[#110508] border p-2 rounded-lg border-brand-light/40 text-cream outline-none text-xs cursor-pointer"
                            >
                              {COMMITTEES.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                            
                            <label className="block text-[9.5px] uppercase text-cream/80 font-bold mt-2">Portfolio Choice</label>
                            <input
                              type="text"
                              name="portfolioPreference2"
                              placeholder="e.g. France or BJP Member"
                              value={formData.portfolioPreference2}
                              onChange={handleInputChange}
                              className="w-full bg-[#110508]/40 border p-2.5 rounded-lg border-brand-light/20 text-cream text-xs outline-none focus:border-brand-light placeholder-cream/25"
                            />
                          </div>

                          {/* Prefer 3 */}
                          <div className="p-3 bg-[#110508]/60 rounded-xl border border-brand-light/25 space-y-2 relative">
                            <span className="absolute -top-2 left-3 bg-[#110508] px-1.5 border border-brand-light/30 text-[8.5px] text-cream/50 font-bold">3RD CHOICE</span>
                            <label className="block text-[9.5px] uppercase text-cream/80 font-bold mb-1 mt-1">Tertiary Council</label>
                            <select
                              name="committeePreference3"
                              value={formData.committeePreference3}
                              onChange={handleInputChange}
                              className="w-full bg-[#110508] border p-2 rounded-lg border-brand-light/40 text-cream outline-none text-xs cursor-pointer"
                            >
                              {COMMITTEES.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                            
                            <label className="block text-[9.5px] uppercase text-cream/80 font-bold mt-2">Portfolio Choice</label>
                            <input
                              type="text"
                              name="portfolioPreference3"
                              placeholder="e.g. China or India Representative"
                              value={formData.portfolioPreference3}
                              onChange={handleInputChange}
                              className="w-full bg-[#110508]/40 border p-2.5 rounded-lg border-brand-light/20 text-cream text-xs outline-none focus:border-brand-light placeholder-cream/25"
                            />
                          </div>

                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Step 3: Treasury Remittance & Checkout verification */}
                  {step === 3 && (
                    <motion.div
                      key="step3-checkout"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -25 }}
                      className="space-y-4 text-left"
                    >
                      <div className="border-b border-brand-light/15 pb-4">
                        <span className="font-mono text-[9px] uppercase tracking-widest text-emerald-400 font-black block">TREASURY CLEARANCE DIRECTIVE // PROTOCOL_03</span>
                        <h4 className="font-serif font-extrabold text-cream text-xl flex items-center gap-2 mt-1">
                          <CreditCard className="w-5.5 h-5.5 text-yellow-500" /> Treasury Ledger Settling Desk
                        </h4>
                        <p className="text-xs text-cream/60 mt-1">Validate transaction ledger codes to lock portfolio allocation and write certificates.</p>
                      </div>

                      {/* Invoice docket card */}
                      <div className="bg-[#110508] border border-brand-light/35 rounded-xl p-4.5 space-y-3 text-sm">
                        <div className="flex justify-between items-center text-xs border-b border-brand-light/20 pb-2.5">
                          <span className="text-cream/70 font-mono">Ledger Category: {formData.delegationType} Delegation Package</span>
                          <span className="font-mono text-gold font-semibold">₹ {formData.delegationType === "Single" ? "1,500.00" : "2,800.00"}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs font-bold border-b border-brand-light/20 pb-2.5">
                          <span className="text-cream flex items-center gap-1.5">
                            <ShieldCheck className="w-4 h-4 text-emerald-500" />
                            General Assembly Administrative Levy
                          </span>
                          <span className="font-mono text-emerald-400">INCL / FREE</span>
                        </div>
                        <div className="flex justify-between items-center text-base font-extrabold text-cream pt-1">
                          <span>Verified Outstanding Fee (INR)</span>
                          <span className="font-mono text-gold animate-pulse text-lg">₹ {feeAmount}.00</span>
                        </div>
                      </div>

                      {/* Real UPI scanner instructions */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-brand-medium/10 p-4.5 border border-brand-light/25 rounded-2xl items-center">
                        <div className="space-y-2">
                          <span className="font-mono text-[8.5px] uppercase px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/35 text-emerald-400 font-black">SECURE LEDGER CHANNEL Verified</span>
                          <p className="font-mono text-[10px] uppercase text-[#ebd07b] font-black">UPI DOCKET TRANSACTION GUIDE</p>
                          <p className="text-[11px] text-cream/70 leading-relaxed">
                            To complete your registration, send your fee amount (<strong className="text-cream">₹{feeAmount}</strong>) to the secretariat payment node. Enter your UPI Transaction Reference Code below to secure allotment.
                          </p>
                          <p className="text-[10px] text-gold/60 font-mono bg-[#110508] p-2 border border-brand-light/10 rounded">
                            UPI ID: <span className="text-cream font-bold">secretariat@okicici</span>
                          </p>
                        </div>
                        
                        <div className="space-y-3">
                          <label className="block font-mono text-[10px] uppercase text-gold font-black tracking-widest pl-0.5">UPI Reference ID Key <span className="text-rose-400">*</span></label>
                          <div className="relative group">
                            <input
                              type="text"
                              name="paymentReceiptNumber"
                              value={formData.paymentReceiptNumber}
                              onChange={handleInputChange}
                              placeholder="e.g., UPI-09482749"
                              className={`w-full bg-[#110508] border p-3 rounded-xl border-brand-light/40 text-cream text-xs outline-none focus:border-gold focus:ring-1 focus:ring-gold/30 placeholder-cream/25 font-mono ${errors.paymentReceiptNumber ? "border-rose-400" : ""}`}
                            />
                            <Terminal className="absolute right-3.5 top-3.5 w-4.5 h-4.5 text-cream/20 group-focus-within:text-gold/40 transition-colors" />
                          </div>
                          <p className="text-[9px] text-[#ebd07b]/40 font-mono pl-1">Enter your 12-digit transaction ID or reference code from bank receipt.</p>
                          {errors.paymentReceiptNumber && (
                            <span className="text-[9.5px] text-rose-400 flex items-center gap-1 font-mono mt-1 font-bold">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />{errors.paymentReceiptNumber}
                            </span>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}

                </AnimatePresence>
              </div>

              

            </div>

            {/* Action Footer Progress controls */}
            <div className="bg-[#120508]/80 border-t border-brand-light/25 p-5 px-7 flex flex-col sm:flex-row justify-between items-center gap-3">
              <div className="text-left">
                <span className="font-mono text-[8px] text-[#ebd07b]/60 uppercase tracking-widest block font-bold leading-normal">
                  SYSTEM CLEARANCE VERIFIED BY EDOPIA SECRETARIAT © 2026
                </span>
                <span className="text-[9.5px] text-cream/40 block mt-0.5 font-sans">
                  Secure direct remittance channel with client encryption.
                </span>
              </div>
              
              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                {step > 1 && (
                  <button
                    onClick={prevStep}
                    type="button"
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 text-xs text-cream/70 hover:text-gold hover:underline font-bold transition-colors py-2 px-4 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" /> Previous Step
                  </button>
                )}

                {step < 3 ? (
                  <button
                    onClick={nextStep}
                    type="button"
                    className="flex-1 sm:flex-initial bg-gold text-[#1f030a] font-sans px-6 py-2.5 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 hover:bg-gold-light hover:scale-102 transition-all duration-200 cursor-pointer shadow-[0_0_15px_rgba(212,175,55,0.25)]"
                  >
                    <span>Continue Verification</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={handlePaymentSubmit}
                    disabled={paymentPending || paymentSuccess}
                    type="button"
                    className="flex-1 sm:flex-initial bg-emerald-500 text-brand-dark hover:bg-emerald-400 font-sans px-6 py-2.5 rounded-xl font-extrabold text-xs flex items-center justify-center gap-2 transition-all duration-300 disabled:opacity-50 cursor-pointer shadow-[0_0_15px_rgba(16,185,129,0.25)]"
                  >
                    {paymentPending ? (
                      <>
                        <div className="w-4 h-4 border-2 border-brand-dark border-t-transparent rounded-full animate-spin" />
                        <span>Reconciling Ledger...</span>
                      </>
                    ) : (
                      <>
                        <ClipboardCheck className="w-4.5 h-4.5" />
                        <span>Submit & Forge Delegate Badge</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : (
        /* DYNAMIC DELEGATE PORTAL BOARD */
        <div id="delegate-portal-dashboard" className="space-y-8 animate-fade-in text-left">
          
          {/* Dashboard Welcome Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-r from-card-dark to-[#14080a] p-6 rounded-2xl border border-brand-light/25">
            <div>
              <span className="font-mono text-xs text-gold uppercase tracking-widest font-extrabold flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-brand-light rounded-full animate-ping" />
                Sovereign Administrative Portal
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif font-black text-cream">
                Delegate Desk: {registeredUser.fullName}
              </h2>
              <p className="text-xs text-cream/60">
                Registered from <strong className="text-cream">{registeredUser.institution}</strong> • Tracking Allocation Quotas
              </p>
            </div>

            <button
              onClick={handleResetRegistration}
              className="flex items-center gap-1.5 bg-brand/35 text-gold-light border border-brand-light/40 hover:bg-brand-medium/50 px-4 py-1.5 rounded-lg text-xs font-mono tracking-wider font-semibold cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Release Portfolio
            </button>
          </div>

          {/* Grid Layout: Badge Left, Actions Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* COLUMN 1 (40% width): Official Printable Assembly Badge */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div 
                id="printable-delegate-badge"
                className="w-full max-w-[340px] bg-gradient-to-b from-card-dark to-brand-dark border-2 border-gold/40 rounded-3xl p-6 shadow-2xl space-y-4 text-center relative overflow-hidden"
              >
                {/* Vintage stamp design element of the badge */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border border-gold/10 rounded-full flex items-center justify-center pointer-events-none">
                  <Logo size="md" withText={false} className="opacity-5 scale-150 rotate-12" />
                </div>

                {/* Badge Header */}
                <div className="flex items-center justify-between border-b border-brand-light/35 pb-2.5">
                  <Logo size="sm" withText={false} />
                  <div className="text-right">
                    <p className="font-serif font-bold text-xs text-cream tracking-wide">EDOPIA MUN</p>
                    <p className="font-mono text-[9px] text-gold tracking-widest leading-none">OFFICIAL DELEGATE</p>
                  </div>
                </div>

                {/* Photo / Avatar Box */}
                <div className="w-24 h-24 rounded-2xl bg-brand-medium/20 border-2 border-gold/30 mx-auto overflow-hidden flex items-center justify-center p-2 mt-4">
                  <div className="w-full h-full rounded-xl bg-brand-light/35 flex items-center justify-center select-none text-cream/70">
                    <User className="w-10 h-10" />
                  </div>
                </div>

                {/* Delegate Credentials */}
                <div className="space-y-1">
                  <h4 className="font-serif text-lg font-bold text-cream tracking-wide truncate">
                    {registeredUser.fullName}
                  </h4>
                  <p className="font-mono text-[10px] text-gold tracking-widest uppercase font-semibold">
                    ID: {registeredUser.id}
                  </p>
                </div>

                {/* Clear Allocation Notice Box */}
                <div className="bg-[#120508]/70 border border-brand-light/45 rounded-xl py-3 px-4 text-center">
                  <p className="font-mono text-[9px] text-[#ebd07b] uppercase tracking-wider font-extrabold mb-0.5">ALLOCATED SEAT ASSEMBLY</p>
                  <p className="font-serif text-xl font-bold text-cream">
                    {allottedCommObj?.name || registeredUser.allottedCommittee}
                  </p>
                  <p className="font-mono text-[10px] text-cream/80 font-semibold italic truncate mt-0.5">
                    Portfolio: {registeredUser.allottedPortfolio}
                  </p>
                </div>

                {/* Barcode & Security stamp */}
                <div className="pt-2 border-t border-brand-light/20 flex items-center justify-between">
                  {/* Mock barcode strip */}
                  <div className="flex gap-[2px] h-8 opacity-75">
                    {[2,3,1,4,2,3,1,2,4,1,2,3].map((val, idx) => (
                      <div key={idx} className="bg-cream" style={{ width: `${val}px` }} />
                    ))}
                  </div>
                  <div className="text-right">
                    <span className="block font-mono text-[8px] text-cream/50 tracking-widest leading-none">VERIFIED SEAT</span>
                    <span className="font-mono text-[10px] text-emerald-400 font-bold leading-none">SECRETARIAT APPROVED</span>
                  </div>
                </div>
              </div>

              {/* Badge CTA download action */}
              <button
                onClick={() => window.print()}
                className="mt-6 flex items-center gap-2 px-6 py-2.5 rounded-xl border border-brand-light/40 bg-card-dark text-gold font-sans text-xs font-bold hover:bg-gold hover:text-brand-dark hover:scale-102 transition-all cursor-pointer shadow-lg"
              >
                <Download className="w-4 h-4" /> Print Delegate Badge / Placard
              </button>
            </div>

            {/* COLUMN 2 (60% width): Interactive Desks & Task submissions */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Bureau Alerts bulletin desk */}
              <div className="bg-[#110508]/60 border border-brand-light/15 rounded-xl p-5">
                <h4 className="font-serif text-base font-bold text-cream flex items-center gap-2 mb-3">
                  <Award className="w-5 h-5 text-gold" /> Secretariat Allocation Bulletin
                </h4>
                <div className="space-y-2.5">
                  <div className="flex gap-2.5 items-start text-xs bg-brand/30 border border-brand-light/20 p-2.5 rounded-lg">
                    <span className="w-1.5 h-1.5 rounded-full bg-gold mt-1.5 animate-pulse" />
                    <div>
                      <p className="font-bold text-cream">Transaction Verified & Docket Closed</p>
                      <p className="text-cream/50 mt-0.5 text-[11px]">Approved via Ledger Code {registeredUser.paymentReceiptNumber}. Seat allotment secured.</p>
                    </div>
                  </div>

                  <div className="flex gap-2.5 items-start text-xs bg-[#151213]/40 p-2.5 rounded-lg">
                    <span className="w-1.5 h-1.5 rounded-full bg-cream/30 mt-1.5" />
                    <div>
                      <p className="font-semibold text-cream/75">Rules of Procedure Released</p>
                      <p className="text-cream/50 mt-0.5 text-[11px]">Please click to review the formal UN Rules of Procedure on Day 1.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Position Paper Submission drop desk */}
              <div className="bg-gradient-to-b from-card-dark to-[#130709] border border-brand-light/25 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-brand-light/15 pb-3">
                  <div>
                    <h4 className="font-serif text-base font-bold text-cream flex items-center gap-2">
                      <FileText className="w-5 h-5 text-gold" /> Position Paper Submission Desk
                    </h4>
                    <p className="text-xs text-cream/50 mt-0.5">Required for Award Category Nominations. Max size 5 MB.</p>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/30 font-bold">
                    PRE-CONFERENCE DEADLINE
                  </span>
                </div>

                {!positionPaper ? (
                  <div className="border-2 border-dashed border-brand-light/30 hover:border-gold/40 rounded-xl p-6 text-center bg-brand-dark/20 relative transition-colors">
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx"
                      onChange={triggerPaperUpload}
                      disabled={uploadingPaper}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    {uploadingPaper ? (
                      <div className="space-y-3">
                        <div className="w-10 h-10 border-2 border-gold border-t-transparent rounded-full animate-spin mx-auto" />
                        <div>
                          <p className="text-xs text-cream font-bold">Encrypting & Uploading Position Paper</p>
                          <div className="w-32 bg-brand/40 h-1.5 rounded-full mx-auto mt-2 overflow-hidden">
                            <div className="bg-gold h-full" style={{ width: `${uploadProgress}%` }} />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <FileText className="w-8 h-8 text-cream/30 mx-auto" />
                        <div>
                          <p className="text-xs font-semibold text-cream">Drag-and-Drop or Click to browse</p>
                          <p className="text-[10px] text-cream/50 mt-1">Accepts PDF, DOCX formats</p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-between p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                      <div>
                        <p className="font-sans font-bold text-xs text-cream truncate max-w-[200px] sm:max-w-xs">{positionPaper.name}</p>
                        <p className="text-[10px] text-cream/50 font-mono">Submitted on {positionPaper.date} ({positionPaper.size})</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setPositionPaper(null)}
                      className="text-xs font-mono text-rose-400 hover:text-rose-300 font-bold px-3 py-1 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Re-upload
                    </button>
                  </div>
                )}
              </div>

              

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
