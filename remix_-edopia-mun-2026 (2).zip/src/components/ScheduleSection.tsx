import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Clock, MapPin, Coffee, Users, ScrollText, CalendarRange } from "lucide-react";
import { SCHEDULE_DAY_1, SCHEDULE_DAY_2 } from "../data";
import { DaySchedule } from "../types";

export default function ScheduleSection() {
  const [activeDay, setActiveDay] = useState<1 | 2>(1);

  const activeSchedule = activeDay === 1 ? SCHEDULE_DAY_1 : SCHEDULE_DAY_2;

  const eventTypeIcons = {
    academic: ScrollText,
    ceremony: Users,
    social: Users,
    break: Coffee,
  };

  const eventColors = {
    academic: {
      bg: "bg-gold/15 border-gold/45",
      text: "text-gold-light",
      node: "bg-gold ring-gold-light/40"
    },
    ceremony: {
      bg: "bg-emerald-500/15 border-emerald-500/40",
      text: "text-emerald-400",
      node: "bg-emerald-500 ring-emerald-500/30"
    },
    social: {
      bg: "bg-sky-500/15 border-sky-500/40",
      text: "text-sky-400",
      node: "bg-sky-500 ring-sky-500/30"
    },
    break: {
      bg: "bg-brand-medium/20 border-brand-light/25",
      text: "text-cream/80",
      node: "bg-brand-light ring-brand-light/20"
    }
  };

  return (
    <div id="schedule-section-wrapper" className="max-w-4xl mx-auto px-4 sm:px-6 pb-20">
      {/* Editorial Header */}
      <div className="text-center space-y-4 mb-16">
        <span className="font-mono text-xs text-gold uppercase tracking-widest font-extrabold px-3 py-1 bg-brand-medium/50 border border-brand-light/30 rounded-full">
          The Session Ledger
        </span>
        <h2 className="text-3xl sm:text-5xl font-serif font-bold text-cream tracking-wide flex items-center justify-center gap-3">
          <CalendarRange className="w-8 h-8 text-gold" /> Schedule & Timeline
        </h2>
        <p className="text-sm sm:text-base text-cream/70 font-sans max-w-2xl mx-auto">
          Review the precise chronological mapping of academic sessions, lobbying buffers, executive cuisines, and valedictorian segments.
        </p>
      </div>

      {/* Slide Toggle Bar */}
      <div className="flex justify-center mb-12">
        <div className="relative flex bg-[#110508] border border-brand-light/30 p-1.5 rounded-2xl w-full max-w-sm relative">
          
          <button
            onClick={() => setActiveDay(1)}
            className={`w-1/2 py-3 rounded-xl font-sans text-xs font-bold tracking-wider uppercase z-10 transition-colors ${
              activeDay === 1 ? "text-brand-dark" : "text-cream/70 hover:text-cream"
            }`}
          >
            Day 1 (July 4)
          </button>
          
          <button
            onClick={() => setActiveDay(2)}
            className={`w-1/2 py-3 rounded-xl font-sans text-xs font-bold tracking-wider uppercase z-10 transition-colors ${
              activeDay === 2 ? "text-brand-dark" : "text-cream/70 hover:text-cream"
            }`}
          >
            Day 2 (July 5)
          </button>

          {/* Framer motion sliding element */}
          <motion.div
            layoutId="scheduleDaySlider"
            className="absolute inset-y-1.5 rounded-xl bg-[#ebd07b]"
            style={{
              width: "calc(50% - 6px)",
              left: activeDay === 1 ? "6px" : "calc(50%)"
            }}
            transition={{ type: "spring", stiffness: 350, damping: 30 }}
          />
        </div>
      </div>

      {/* Chronological Vertical Timeline with AnimatePresence */}
      <div className="relative pl-6 sm:pl-10 space-y-8 text-left border-l border-brand-light/20 ml-2">
        <AnimatePresence mode="popLayout">
          {activeSchedule.map((slot, index) => {
            const Icon = eventTypeIcons[slot.type];
            const colors = eventColors[slot.type];
            return (
              <motion.div
                key={`${activeDay}-${index}-${slot.title}`}
                initial={{ opacity: 0, x: -15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 15 }}
                transition={{ duration: 0.35, delay: index * 0.08 }}
                className="relative group space-y-2.5"
              >
                {/* Pulsating Bullet Indicator Node */}
                <span className={`absolute -left-[31px] sm:-left-[47px] top-1 w-4 h-4 rounded-full border-2 border-slate-bg ring-4 flex items-center justify-center transition-transform group-hover:scale-110 duration-200 ${colors.node}`} />

                {/* Event Card Panel */}
                <div className={`p-5 rounded-2xl border backdrop-blur-sm transition-all group-hover:bg-brand-medium/10 shadow-lg ${colors.bg}`}>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-brand-light/10 pb-3 mb-3">
                    <div className="flex items-center gap-2">
                      <Clock className={`w-4 h-4 ${colors.text}`} />
                      <span className="font-mono text-[11px] font-bold tracking-wider uppercase text-cream">
                        {slot.time}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-cream/60">
                      <MapPin className="w-3.5 h-3.5 text-gold/80" />
                      <span className="text-[10px] font-mono tracking-widest uppercase font-semibold text-[#ebd07b]">
                        {slot.venue}
                      </span>
                    </div>
                  </div>

                  <h4 className="font-serif text-xl sm:text-2xl font-bold text-cream tracking-wide group-hover:text-gold transition-colors">
                    {slot.title}
                  </h4>
                  <p className="text-xs text-cream/70 leading-relaxed mt-1">
                    {slot.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Footer guideline */}
      <div className="mt-12 text-center text-xs font-mono text-cream/40 italic">
        * All delegates must reach respective committee venues at least 15 minutes before the gavel sounds.
      </div>
    </div>
  );
}
