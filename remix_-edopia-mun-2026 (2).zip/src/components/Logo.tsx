import React from "react";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  withText?: boolean;
}

export default function Logo({ className = "", size = "md", withText = true }: LogoProps) {
  const sizeClasses = {
    sm: "w-10 h-10",
    md: "w-20 h-20",
    lg: "w-44 h-44",
    xl: "w-64 h-64",
  };

  return (
    <div id="edopia-logo-container" className={`flex flex-col items-center justify-center select-none ${className}`}>
      <svg
        id="edopia-logo-svg"
        viewBox="0 0 500 500"
        fill="currentColor"
        className={`${sizeClasses[size]} text-gold hover:text-gold-light transition-all duration-300 drop-shadow-[0_0_15px_rgba(131,32,64,0.35)]`}
      >
        {/* Top Pixel Typography: "EDOPIA" & "- MUN -" */}
        {withText && (
          <g id="logo-top-text" fill="currentColor" className="text-gold">
            {/* E */}
            <path d="M 153 40 h 24 v 7 h -17 v 7 h 14 v 7 h -14 v 7 h 17 v 7 h -24 Z" />
            {/* D */}
            <path d="M 187 40 h 17 l 7 7 v 21 l -7 7 h -17 Z M 194 47 v 21 h 8 l 3 -3 v -15 l -3 -3 Z" />
            {/* O */}
            <path d="M 221 40 h 24 v 35 h -24 Z M 228 47 v 21 h 10 v -21 Z" />
            {/* P */}
            <path d="M 255 40 h 24 v 21 h -17 v 14 h -7 Z M 262 47 v 7 h 10 v -7 Z" />
            {/* I */}
            <path d="M 289 40 h 24 v 7 h -8.5 v 21 h 8.5 v 7 h -24 v -7 h 8.5 v -21 h -8.5 Z" />
            {/* A */}
            <path d="M 323 40 h 24 v 35 h -7 v -14 h -10 v 14 h -7 Z M 330 47 v 7 h 10 v -7 Z" />

            {/* - MUN - */}
            {/* Hyphen 1 */}
            <rect x="195" y="98" width="12" height="6" />
            {/* M */}
            <path d="M 215 90 h 18 v 22 h -5 v -13 l -4 4 l -4 -4 v 13 h -5 Z" />
            {/* U */}
            <path d="M 241 90 h 5 v 17 h 8 v -17 h 5 v 22 h -18 Z" />
            {/* N */}
            <path d="M 267 90 h 5 v 7 l 6 8 v -15 h 5 v 22 h -4 l -7 -9 v 9 h -5 Z" />
            {/* Hyphen 2 */}
            <rect x="293" y="98" width="12" height="6" />
          </g>
        )}

        {/* Concentric UN-style Target Globe Grid */}
        <g id="globe-grid" stroke="currentColor" strokeWidth="5" fill="none" opacity="0.9">
          <circle cx="250" cy="265" r="100" />
          <circle cx="250" cy="265" r="80" />
          <circle cx="250" cy="265" r="60" />
          <circle cx="250" cy="265" r="40" />
          <circle cx="250" cy="265" r="20" />
          {/* Meridians (Longitudes) */}
          <line x1="250" y1="165" x2="250" y2="365" />
          <line x1="150" y1="265" x2="350" y2="265" />
          {/* Diagonals */}
          <line x1="179.3" y1="194.3" x2="320.7" y2="335.7" />
          <line x1="179.3" y1="335.7" x2="320.7" y2="194.3" />
        </g>

        {/* Continents filled inside the globe */}
        <g id="pixel-continents" fill="currentColor" opacity="0.9">
          {/* North America */}
          <rect x="170" y="180" width="30" height="20" />
          <rect x="190" y="200" width="40" height="30" />
          <rect x="210" y="230" width="15" height="15" />
          {/* South America */}
          <rect x="215" y="255" width="25" height="35" />
          <rect x="220" y="290" width="15" height="35" />
          <rect x="225" y="325" width="8" height="20" />
          {/* Eurasia */}
          <rect x="260" y="170" width="85" height="35" />
          <rect x="270" y="205" width="70" height="30" />
          <rect x="240" y="190" width="30" height="20" />
          {/* Africa */}
          <rect x="275" y="245" width="45" height="40" />
          <rect x="285" y="285" width="25" height="35" />
          <rect x="290" y="320" width="10" height="15" />
          {/* Australia */}
          <rect x="330" y="295" width="30" height="20" />
          <rect x="340" y="315" width="15" height="10" />
        </g>

        {/* Wreath Left Wing */}
        <g id="wreath-left" fill="currentColor" opacity="0.9">
          <path d="M 250,435 C 180,425 100,360 75,250 C 65,190 80,140 95,125 C 93,135 85,180 95,240 C 110,340 180,395 250,405" stroke="currentColor" strokeWidth="7" fill="none" />
          {/* Leaf blocks */}
          <rect x="210" y="425" width="15" height="10" transform="rotate(-10 210 425)" />
          <rect x="175" y="415" width="18" height="12" transform="rotate(-20 175 415)" />
          <rect x="140" y="392" width="20" height="12" transform="rotate(-30 140 392)" />
          <rect x="110" y="358" width="22" height="12" transform="rotate(-40 110 358)" />
          <rect x="85" y="313" width="22" height="12" transform="rotate(-50 85 313)" />
          <rect x="70" y="260" width="22" height="12" transform="rotate(-65 70 260)" />
          <rect x="65" y="202" width="22" height="12" transform="rotate(-80 65 202)" />
          <rect x="72" y="148" width="22" height="12" transform="rotate(-95 72 148)" />
          <rect x="90" y="105" width="20" height="10" transform="rotate(-110 90 105)" />
        </g>

        {/* Wreath Right Wing */}
        <g id="wreath-right" fill="currentColor" opacity="0.9">
          <path d="M 250,435 C 320,425 400,360 425,250 C 435,190 420,140 405,125 C 407,135 415,180 405,240 C 390,340 320,395 250,405" stroke="currentColor" strokeWidth="7" fill="none" />
          {/* Leaf blocks */}
          <rect x="275" y="425" width="15" height="10" transform="rotate(10 275 425)" />
          <rect x="307" y="415" width="18" height="12" transform="rotate(20 307 415)" />
          <rect x="340" y="392" width="20" height="12" transform="rotate(30 340 392)" />
          <rect x="368" y="358" width="22" height="12" transform="rotate(40 368 358)" />
          <rect x="393" y="313" width="22" height="12" transform="rotate(50 393 313)" />
          <rect x="408" y="260" width="22" height="12" transform="rotate(65 408 260)" />
          <rect x="413" y="202" width="22" height="12" transform="rotate(80 413 202)" />
          <rect x="406" y="148" width="22" height="12" transform="rotate(95 406 148)" />
          <rect x="390" y="105" width="20" height="10" transform="rotate(110 390 105)" />
        </g>

        {/* Central Star below the globe */}
        <path d="M 250,432 L 254,441 L 263,441 L 256,447 L 259,456 L 250,450 L 241,456 L 244,447 L 237,441 L 246,441 Z" fill="currentColor" className="text-gold" />

        {/* Bottom pixel star coordinates: "2026" */}
        <g id="logo-bottom-year" fill="currentColor" className="text-gold">
          {/* 2 */}
          <path d="M 213 462 h 14 v 4 h -10 v 4 h 10 v 12 h -14 v -4 h 10 v -4 h -10 Z" />
          {/* 0 */}
          <path d="M 233 462 h 14 v 20 h -14 Z M 238 466 v 12 h 4 v -12 Z" />
          {/* 2 */}
          <path d="M 253 462 h 14 v 4 h -10 v 4 h 10 v 12 h -14 v -4 h 10 v -4 h -10 Z" />
          {/* 6 */}
          <path d="M 273 462 h 14 v 4 h -10 v 4 h 10 v 12 h -14 Z M 278 471 h 4 v 7 h -4 Z" />
        </g>
      </svg>
    </div>
  );
}
