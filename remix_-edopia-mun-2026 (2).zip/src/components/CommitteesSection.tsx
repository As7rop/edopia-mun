import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Download, Users, ShieldAlert, BadgeInfo, CheckCircle2, ChevronRight, CornerDownRight } from "lucide-react";
import { COMMITTEES } from "../data";
import { Committee } from "../types";

interface CommitteesSectionProps {
  setActiveTab: (tab: string) => void;
  setSelectedCommitteeId: (id: string | null) => void;
}

export default function CommitteesSection({ setActiveTab, setSelectedCommitteeId }: CommitteesSectionProps) {
  const [activeCommittee, setActiveCommittee] = useState<Committee | null>(null);
  const [downloadingGuide, setDownloadingGuide] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [completedGuides, setCompletedGuides] = useState<string[]>([]);

  const triggerDownload = (committeeId: string) => {
    if (completedGuides.includes(committeeId)) return;
    
    setDownloadingGuide(committeeId);
    setDownloadProgress(0);
    
    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setDownloadingGuide(null);
            setCompletedGuides((completed) => [...completed, committeeId]);
          }, 600);
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  const badgeColorMap = {
    Beginner: "bg-emerald-500/20 text-emerald-400 border-emerald-500/40",
    Intermediate: "bg-sky-500/20 text-sky-400 border-sky-500/40",
    Advanced: "bg-orange-500/20 text-orange-400 border-orange-500/40",
    "Double Delegation": "bg-brand-light/40 text-rose-300 border-brand-light/60",
    "Team of 4": "bg-rose-500/20 text-rose-300 border-rose-500/40",
  };

  const handleClaimPortfolio = (committeeId: string) => {
    setSelectedCommitteeId(committeeId);
    setActiveTab("dashboard");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div id="committees-section-wrapper" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      {/* Editorial Header with Edgy Styling */}
      <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
        <span className="font-mono text-xs text-gold uppercase tracking-widest font-extrabold px-3 py-1 bg-brand-medium/50 border border-brand-light/30 rounded-none border-l-2 border-r-2 animate-pulse">
          THE COUNCIL CATALOG // ACTIVE CHANNELS
        </span>
        <h2 className="text-3xl sm:text-5xl font-serif font-black text-cream tracking-wide">
          Sovereign Executive Assemblies
        </h2>
        <p className="text-xs sm:text-sm text-cream/70 font-sans">
          Select an assembly key-panel to authenticate core agendas, review executive board directives, track sovereign seat spaces, and download custom dynamic study dossiers.
        </p>
      </div>



      {/* Grid of Committees with Edgy Tech Styling */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {COMMITTEES.map((comm) => (
          <motion.div
            key={comm.id}
            layoutId={`comm-card-${comm.id}`}
            whileHover={{ 
              y: -8,
              scale: 1.015,
              borderColor: "rgba(212, 175, 55, 0.55)",
              boxShadow: "0 20px 30px -10px rgba(74, 15, 33, 0.4), 0 0 20px rgba(212, 175, 55, 0.15)"
            }}
            whileTap={{ scale: 0.985 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            onClick={() => setActiveCommittee(comm)}
            className="group cursor-pointer bg-gradient-to-br from-card-dark to-[#130709] border border-brand-light/25 rounded-none p-6 shadow-2xl tech-corners cyber-border relative overflow-hidden"
          >
            {/* Corner diagonal accent overlay */}
            <div className="absolute top-0 right-0 w-8 h-8 opacity-5 group-hover:opacity-15 pointer-events-none border-r border-t border-gold transition-opacity" />
            
            {comm.difficulty !== "Beginner" && comm.difficulty !== "Intermediate" && comm.difficulty !== "Advanced" && (
              <div className="flex items-center justify-between mb-4 relative z-10">
                <span className={`text-[10px] font-mono tracking-wider px-2.5 py-1 rounded-none border ${badgeColorMap[comm.difficulty]}`}>
                  {comm.difficulty}
                </span>
              </div>
            )}

            <h3 className="font-serif text-3xl font-extrabold text-cream leading-none group-hover:text-gold transition-colors duration-300">
              {comm.name}
            </h3>
            <p className="font-mono text-[10px] text-gold uppercase tracking-widest mt-1.5 font-bold">
              {comm.fullName}
            </p>

            <p className="text-xs text-cream/70 mt-4 line-clamp-3 leading-relaxed relative z-10">
              {comm.agenda}
            </p>

            <div className="mt-6 pt-4 border-t border-brand-light/20 flex items-center justify-between text-xs font-mono font-semibold text-gold group-hover:text-gold-light transition-colors">
              <span>AUTHENTICATE PORTAL DESK //</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Committee Full Desk Modal */}
      <AnimatePresence>
        {activeCommittee && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 overflow-y-auto backdrop-blur-md bg-black/80 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-card-dark border border-brand-light/30 rounded-3xl p-6 sm:p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative scrollbar-none"
            >
              {/* Close Button */}
              <button
                onClick={() => setActiveCommittee(null)}
                className="absolute top-4 right-4 sm:top-6 sm:right-6 p-2 rounded-full text-cream/70 hover:text-gold hover:bg-brand-medium/50 border border-brand-light/20 transition-all"
              >
                ✕
              </button>

              {/* Modal Body */}
              <div className="space-y-8">
                {/* Header */}
                <div>
                  {activeCommittee.difficulty !== "Beginner" && activeCommittee.difficulty !== "Intermediate" && activeCommittee.difficulty !== "Advanced" && (
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`text-[10px] font-mono tracking-widest px-2.5 py-1 rounded-md border ${badgeColorMap[activeCommittee.difficulty]}`}>
                        {activeCommittee.difficulty}
                      </span>
                    </div>
                  )}
                  <h3 className="font-serif text-4xl sm:text-5xl font-black text-cream leading-tight">
                    {activeCommittee.name}
                  </h3>
                  <p className="font-mono text-xs text-gold uppercase tracking-widest font-extrabold mt-1">
                    {activeCommittee.fullName}
                  </p>
                </div>

                {/* Grid Info */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 border-t border-brand-light/20 pt-6">
                  {/* Left Column: Agenda detail & Description */}
                  <div className="lg:col-span-12 space-y-6">
                    <div>
                      <h4 className="font-mono text-xs text-gold uppercase tracking-wider font-extrabold mb-1">
                        Primary Dossier Agenda
                      </h4>
                      <p className="font-serif italic text-lg text-cream leading-relaxed font-semibold">
                        "{activeCommittee.agenda}"
                      </p>
                    </div>

                    <div>
                      <h4 className="font-mono text-xs text-gold uppercase tracking-wider font-extrabold mb-1">
                        Council Mandate & Charter
                      </h4>
                      <p className="text-sm text-cream/80 leading-relaxed text-justify">
                        {activeCommittee.description}
                      </p>
                    </div>
                  </div>
                </div>



                {/* Bottom action bar */}
                <div className="pt-4 border-t border-brand-light/20 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <span className="font-mono text-xs text-cream/50">
                    Edopia MUN 2026 Admin Desk • Standard Allocation Guidelines Apply
                  </span>
                  <button
                    onClick={() => handleClaimPortfolio(activeCommittee.id)}
                    className="w-full sm:w-auto bg-[#ebd07b] text-brand-dark px-6 py-3 rounded-xl font-bold font-sans text-xs flex items-center justify-center gap-2 hover:bg-gold-light hover:scale-102 cursor-pointer shadow-lg transition-transform"
                  >
                    <span>Register to Claim Portfolio</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
