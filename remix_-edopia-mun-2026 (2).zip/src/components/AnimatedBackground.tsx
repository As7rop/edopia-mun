import React, { useState } from "react";
import { motion } from "motion/react";

export default function AnimatedBackground() {
  const [zoomLevel, setZoomLevel] = useState(1);

  // Cycle zoom scales dynamically on background interaction
  const handleBackgroundClick = () => {
    setZoomLevel((prev) => {
      if (prev >= 2.5) return 1;
      return prev + 0.5;
    });
  };

  // Generate random dots/particles to represent stars or diplomatic stations
  const particles = Array.from({ length: 18 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 2 + 1,
    duration: Math.random() * 15 + 15,
    delay: Math.random() * -20,
  }));

  // Generate some geo-coordinate markers (Deshbandhu, NY UN Headquarters, etc.)
  const markers = [
    { label: "DESHBANDHU.DELHI // 28.5244° N, 77.2536° E", x: "15%", y: "20%" },
    { label: "UN.HQ.NYC // 40.7489° N, 73.9680° W", x: "80%", y: "35%" },
    { label: "UN.GENEVA // 46.2231° N, 6.1396° E", x: "10%", y: "75%" },
    { label: "SEC.ADMIN // ESTD.2026.GLOBAL", x: "70%", y: "80%" },
  ];

  return (
    <div 
      onClick={handleBackgroundClick}
      className="fixed inset-0 -z-50 overflow-hidden bg-[#0c0507] select-none pointer-events-auto cursor-zoom-in"
    >
      <motion.div
        animate={{ 
          scale: zoomLevel,
          rotate: (zoomLevel - 1) * 8, // slight offset rotation for parallax parallax
        }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="absolute inset-0 w-full h-full origin-center flex items-center justify-center"
      >
        {/* Deep Space Atmosphere */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(74,15,33,0.18)_0%,rgba(12,5,7,1)_85%)]" />

        {/* Grid Pattern and Scanning Laser Lines */}
        <div 
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: `
              linear-gradient(rgba(212, 175, 55, 0.15) 1px, transparent 1px),
              linear-gradient(90deg, rgba(212, 175, 55, 0.15) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
          }}
        />

        {/* Holographic Slow Rotating UN Globe Grid Projection */}
        <div className="absolute -right-48 -bottom-48 sm:-right-24 sm:-bottom-24 w-[350px] h-[350px] sm:w-[600px] sm:h-[600px] opacity-[0.08] text-gold">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 75, ease: "linear", repeat: Infinity }}
            className="w-full h-full"
          >
            <svg viewBox="0 0 500 500" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-full h-full">
              {/* Concentric rings */}
              <circle cx="250" cy="250" r="230" strokeDasharray="3 3" />
              <circle cx="250" cy="250" r="190" />
              <circle cx="250" cy="250" r="150" strokeDasharray="8 4" />
              <circle cx="250" cy="250" r="110" />
              <circle cx="250" cy="250" r="70" />
              <circle cx="250" cy="250" r="30" />
              
              {/* Longitude / Meridian spokes */}
              <line x1="25" y1="250" x2="475" y2="250" />
              <line x1="250" y1="25" x2="250" y2="475" />
              <line x1="91" y1="91" x2="409" y2="409" strokeDasharray="4 4" />
              <line x1="91" y1="409" x2="409" y2="91" strokeDasharray="4 4" />

              {/* Simulated Polar Grid Divisions */}
              <path d="M 50,250 A 200,60 0 0,0 450,250" />
              <path d="M 50,250 A 200,60 0 0,1 450,250" />
              <path d="M 90,250 A 160,110 0 0,0 410,250" />
              <path d="M 90,250 A 160,110 0 0,1 410,250" />
              
              {/* Slow Outer Laurel Leaf Borders */}
              <g opacity="0.6" strokeWidth="2">
                <path d="M 250,470 C 150,460 60,380 30,250 C 20,180 40,110 60,90" />
                <path d="M 250,470 C 350,460 440,380 470,250 C 480,180 460,110 440,90" />
              </g>
            </svg>
          </motion.div>
        </div>

        {/* Secondary Top-Left UN Globe Grid Projection */}
        <div className="absolute -left-32 -top-32 w-[250px] h-[250px] sm:w-[450px] sm:h-[450px] opacity-[0.05] text-gold">
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 90, ease: "linear", repeat: Infinity }}
            className="w-full h-full"
          >
            <svg viewBox="0 0 500 500" fill="none" stroke="currentColor" strokeWidth="2" className="w-full h-full">
              <circle cx="250" cy="250" r="220" />
              <circle cx="250" cy="250" r="170" strokeDasharray="5 5" />
              <circle cx="250" cy="250" r="120" />
              <circle cx="250" cy="250" r="70" />
              <line x1="250" y1="0" x2="250" y2="500" />
              <line x1="0" y1="250" x2="500" y2="250" strokeDasharray="2 2" />
            </svg>
          </motion.div>
        </div>

        {/* Holographic Glowing Geo-Coordinates */}
        <div className="absolute inset-0 hidden lg:block opacity-[0.25]">
          {markers.map((marker, idx) => (
            <div
              key={idx}
              className="absolute font-mono text-[8px] sm:text-[9px] text-[#ebd07b]/40 tracking-widest uppercase flex items-center gap-1.5"
              style={{ left: marker.x, top: marker.y }}
            >
              <span className="w-1.5 h-1.5 bg-rose-500 rounded-none animate-ping" />
              <span className="w-1 h-1 bg-gold rounded-none" />
              <span>{marker.label}</span>
            </div>
          ))}
        </div>

        {/* Floating Tactical Dust Particles */}
        {particles.map((p) => (
          <motion.div
            key={p.id}
            className="absolute rounded-full bg-gold/30 hover:bg-gold-light/60 transition-colors"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: p.size,
              height: p.size,
            }}
            animate={{
              y: [0, -120, 0],
              x: [0, Math.sin(p.id) * 40, 0],
              opacity: [0.15, 0.7, 0.15],
            }}
            transition={{
              duration: p.duration,
              repeat: Infinity,
              delay: p.delay,
              ease: "easeInOut",
            }}
          />
        ))}

        {/* Slow Drifting Compass Rose lines */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.02]" xmlns="http://www.w3.org/2000/svg">
          <line x1="0" y1="40%" x2="100%" y2="40%" stroke="#d4af37" strokeWidth="1" />
          <line x1="75%" y1="0" x2="75%" y2="100%" stroke="#d4af37" strokeWidth="1" />
        </svg>
      </motion.div>
    </div>
  );
}
