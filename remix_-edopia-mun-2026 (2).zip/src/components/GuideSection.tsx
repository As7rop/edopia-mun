import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, BookOpen, GraduationCap, ChevronDown, Check, HelpCircle, ArrowRight } from "lucide-react";
import { FAQS } from "../data";
import { FAQItem } from "../types";

export default function GuideSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<"All" | "General" | "Registration" | "Committees" | "Dress Code">("All");
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  
  // Interactive ROP Flow State
  const [selectedRopStage, setSelectedRopStage] = useState<number | null>(1);

  const categories: ("All" | "General" | "Registration" | "Committees" | "Dress Code")[] = [
    "All", "General", "Registration", "Committees", "Dress Code"
  ];

  const ropStages = [
    {
      step: 1,
      title: "Roll Call & Establishing Quorum",
      summary: "First administrative act to log state presence.",
      description: "The EB Chairperson calls each state or member leader. Delegates must respond 'Present' or 'Present and Voting'. Responding 'Present and Voting' denies the right to abstain in final substantive resolution voting rounds.",
      protocol: "Requires minimum 1/3 representation to convene debate."
    },
    {
      step: 2,
      title: "General Speakers List (GSL)",
      summary: "Primary list to articulate structural policy.",
      description: "The default state of debate. Each delegation is added to the GSL to deliver their primary country stance. Typical individual speaking time is 90 seconds. Once completed, remaining time must be yielded to another delegate, questions, or the chair.",
      protocol: "Default flow. Remains open throughout the conference."
    },
    {
      step: 3,
      title: "Moderated Caucus (MC)",
      summary: "A sub-assembly focusing on granular issue areas.",
      description: "A delegate proposes a motion for a moderated caucus, specifying total duration, individual speaking time, and specific topic (e.g., 'Eradicating cyber hacks on core banks'). If passed by majority, the floor debates solely on that topic.",
      protocol: "Formal dialogue. Speakers recognized in turn by the speaker."
    },
    {
      step: 4,
      title: "Unmoderated Caucus (UMC)",
      summary: "Informal workspace to form working blocs.",
      description: "A delegate proposes to suspend formals for an unmoderated caucus. If passed, the floor turns into an open workspace. Delegates mingle freely, draft clauses, merge ideas, debate informally, and construct unified working coalitions.",
      protocol: "No formal speaking list. Lobbying and drafting session."
    },
    {
      step: 5,
      title: "Drafting Resolutions & Amendments",
      summary: "Formulating resolutions to resolve conflicts.",
      description: "Working papers are formatted into official Draft Resolutions containing preambles (problem outline) and operative clauses (action directives). Opposing factions submit hostile or friendly amendments to refine policies.",
      protocol: "Requires Sponsors & Signatories to introduce formally."
    },
    {
      step: 6,
      title: "The Substantive Voting Bloc",
      summary: "Final test of global treaty alignments.",
      description: "Once debate is closed, the committee enters voting. No entry or exit is permitted. Each resolution is voted by roll-call, placards, or division vote. Only resolutions securing simple majority are approved as ratified Edopia Treaties.",
      protocol: "Strict silence. No points or notes permitted."
    }
  ];

  // Filtering FAQ logic
  const filteredFaqs = FAQS.filter(faq => {
    const matchesCategory = activeCategory === "All" || faq.category === activeCategory;
    const matchesSearch = 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleToggleFaq = (index: number) => {
    setExpandedFaq(expandedFaq === index ? null : index);
  };

  return (
    <div id="guide-section-container" className="space-y-16 pb-20 text-left">
      
      {/* Interactive Rules of Procedure Flowchart */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Editorial Title */}
        <div className="text-center max-w-2xl mx-auto space-y-4 mb-12">
          <span className="font-mono text-xs text-gold uppercase tracking-widest font-extrabold px-3 py-1 bg-brand-medium/50 border border-brand-light/30 rounded-full">
            Delegate Training Manual
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-cream tracking-wide flex items-center justify-center gap-2">
            <BookOpen className="w-8 h-8 text-gold" /> Rules of Procedure (ROP) Flow
          </h2>
          <p className="text-xs sm:text-sm text-cream/70 font-sans">
            Understand the dynamic cycle of our diplomatic assemblies. Select any step in the cycle below to unlock official protocols and guidelines.
          </p>
        </div>

        {/* Dynamic Flow Map */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start bg-gradient-to-b from-card-dark to-[#0f0709] p-6 sm:p-8 rounded-3xl border border-brand-light/25">
          {/* Timeline Nodes Selector */}
          <div className="lg:col-span-5 space-y-3">
            <p className="font-mono text-[10px] text-gold uppercase tracking-widest font-extrabold mb-2 text-left">
              ASSEMBLY CHRONOLOGY PIPELINE
            </p>
            {ropStages.map((stage) => {
              const works = selectedRopStage === stage.step;
              return (
                <div
                  key={stage.step}
                  onClick={() => setSelectedRopStage(stage.step)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    works 
                      ? "bg-brand/30 border-gold shadow-lg" 
                      : "bg-[#110508]/40 border-brand-light/10 hover:border-brand-light/45"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-6 h-6 rounded-md font-mono text-xs font-bold flex items-center justify-center ${
                      works ? "bg-gold text-brand-dark" : "bg-brand/20 text-gold-light"
                    }`}>
                      {stage.step}
                    </span>
                    <div>
                      <h4 className={`font-sans font-extrabold text-sm ${works ? "text-gold" : "text-cream"}`}>
                        {stage.title}
                      </h4>
                      <p className="text-[10px] text-cream/50 mt-0.5 font-medium leading-tight">
                        {stage.summary}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Guidelines Dossier Display Panel */}
          <div className="lg:col-span-7 bg-[#110508] border border-brand-light/35 rounded-2xl p-6 sm:p-8 min-h-[300px] flex flex-col justify-between relative">
            <AnimatePresence mode="wait">
              {selectedRopStage && (
                <motion.div
                  key={selectedRopStage}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-4"
                >
                  <div>
                    <span className="font-mono text-[10px] uppercase font-bold text-gold bg-brand/40 px-2.5 py-1 border border-brand-light/30 rounded-md">
                      PROTOCOL STAGE 0{selectedRopStage}
                    </span>
                    <h3 className="font-serif text-2xl sm:text-3xl font-extrabold text-cream tracking-wide mt-3.5">
                      {ropStages[selectedRopStage - 1].title}
                    </h3>
                  </div>

                  <p className="text-sm text-cream/80 leading-relaxed text-justify">
                    {ropStages[selectedRopStage - 1].description}
                  </p>

                  <div className="bg-[#1c0c11] border border-brand-light/20 p-4 rounded-xl flex items-start gap-2.5 mt-6">
                    <GraduationCap className="w-5 h-5 text-[#ebd07b] flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-mono text-[9px] uppercase text-gold font-bold">Secretariat Rule Indicator</p>
                      <p className="text-xs text-cream/70 leading-relaxed italic mt-0.5">
                        {ropStages[selectedRopStage - 1].protocol}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="pt-6 border-t border-brand-light/15 mt-6 flex justify-between items-center text-[10px] font-mono text-cream/40">
              <span>Edopia Training Academy • Rules of Procedure</span>
              <span className="flex items-center gap-1 text-gold">
                Next Stage <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Structured Search-Enabled Q&A FAQs */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto space-y-4 mb-12">
          <h2 className="text-2xl sm:text-4xl font-serif font-bold text-cream tracking-wide flex items-center justify-center gap-2">
            <HelpCircle className="w-8 h-8 text-gold" /> Frequently Answered Questions
          </h2>
          <p className="text-xs sm:text-sm text-cream/70 font-sans">
            Have queries regarding timelines, logistics, dress codes, or payment verification? Query our administrative ledger below.
          </p>
        </div>

        {/* Filter Controls & Search */}
        <div className="space-y-4 bg-card-dark border border-brand-light/20 p-6 rounded-2xl mb-8 shadow-xl">
          {/* Search bar */}
          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 text-cream/40 w-4 h-4" />
            <input
              type="text"
              placeholder="Search queries (e.g., payment, dress code)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#110508] border border-brand-light/35 p-3 pl-10 rounded-xl text-cream text-sm placeholder-cream/35 outline-none focus:border-gold"
            />
          </div>

          {/* Filtering Category Pills */}
          <div className="flex flex-wrap gap-2 pt-2 justify-center">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setActiveCategory(cat);
                  setExpandedFaq(null);
                }}
                className={`px-3.5 py-1.5 rounded-lg border text-xs font-semibold tracking-wider transition-all cursor-pointer ${
                  activeCategory === cat
                    ? "bg-[#ebd07b] border-gold-light text-brand-dark shadow-md"
                    : "bg-brand/20 border-brand-light/20 text-cream/75 hover:border-brand-light/45"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Accordions Container with AnimatePresence */}
        <div className="space-y-3">
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map((faq, index) => {
              const isExpanded = expandedFaq === index;
              return (
                <div
                  key={faq.question}
                  className="bg-gradient-to-b from-[#14080b] to-card-dark border border-brand-light/20 rounded-xl overflow-hidden transition-all duration-300 shadow-md"
                >
                  {/* Head Toggle button */}
                  <button
                    onClick={() => handleToggleFaq(index)}
                    className="w-full p-4 sm:p-5 flex items-center justify-between text-left hover:bg-brand-medium/10 transition-colors cursor-pointer"
                  >
                    <span className="font-sans font-bold text-[#f2e7d5] text-sm sm:text-base leading-snug">
                      {faq.question}
                    </span>
                    <ChevronDown
                      className={`w-5 h-5 text-gold flex-shrink-0 transition-transform duration-300 ml-3 ${
                        isExpanded ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {/* Expandable answer panel */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.25 }}
                        className="border-t border-brand-light/10"
                      >
                        <div className="p-4 sm:p-5 bg-[#0f0608]/40 font-sans text-xs sm:text-sm text-cream/75 leading-relaxed text-left">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })
          ) : (
            <div className="text-center py-10 bg-brand-dark/20 rounded-xl border border-brand-light/20 space-y-2">
              <HelpCircle className="w-8 h-8 text-cream/35 mx-auto animate-pulse" />
              <p className="text-xs font-mono text-cream/50 uppercase tracking-widest">NO REGISTERED QUERY MATCHES "{searchQuery}"</p>
              <p className="text-[11px] text-cream/45">Try broadening your parameters or search within specific categories.</p>
            </div>
          )}
        </div>
      </section>

    </div>
  );
}
